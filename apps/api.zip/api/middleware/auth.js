//D:\surat-menyurat-monorepo\apps\api\middleware\auth.js
// apps/api/middleware/auth.js
import jwt from "jsonwebtoken";

export function authenticate(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);

    req.user = {
      id: payload.id,
      username: payload.username,
      name: payload.name,
      role_id: payload.role_id,
      role_slug: payload.role_slug,
      role: payload.role,
      unit_id: payload.unit_id ?? null,
      unit_slug: payload.unit_slug ?? null,
    };

    next();
  } catch (e) {
    return res.status(401).json({ success: false, message: "Token invalid" });
  }
}
