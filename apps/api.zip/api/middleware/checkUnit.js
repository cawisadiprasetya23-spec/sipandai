export function requireUnitForRole(req, res, next) {
  const user = req.user;

  if (!user) {
    return res.status(401).json({
      success: false,
      message: "Unauthorized"
    });
  }

  const role = user.role;
  const unitId = user.unit_id;

  // Role yang TIDAK wajib punya unit
  //const rolesWithoutUnit = ["SUPERADMIN", "ADMIN"];
  const rolesWithoutUnitId = [99]; // misalnya role_id 99 = Admin BKPSDM
  // Jika role tidak wajib unit → lanjut
  if (rolesWithoutUnitId.includes(user.role_id)) {
    return next();
  }

  // Role wajib unit → cek unit_id
  if (!unitId) {
    return res.status(400).json({
      success: false,
      message: `Unit tidak ditemukan untuk role ${role}. Harap hubungi admin untuk mengatur unit_id.`
    });
  }

  // Lolos
  next();
}
