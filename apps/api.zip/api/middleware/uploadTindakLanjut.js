import multer from "multer";
import path from "path";
import fs from "fs";

function ensureDirSync(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

const uploadDir = path.join(process.cwd(), "uploads", "tindak-lanjut");
ensureDirSync(uploadDir);

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const disposisiId = req.params?.disposisiId || "unknown";
    const ts = Date.now();
    const ext = path.extname(file.originalname || "").toLowerCase();

    // whitelist ext via mimetype later; still keep ext
    const safeExt = ext && ext.length <= 10 ? ext : "";

    cb(null, `tl-disposisi-${disposisiId}-${ts}${safeExt}`);
  },
});

function fileFilter(req, file, cb) {
  const allowed = [
    "application/pdf",
    "image/jpeg",
    "image/png",
  ];
  if (!allowed.includes(file.mimetype)) {
    return cb(new Error("File harus PDF/JPG/PNG"), false);
  }
  cb(null, true);
}

export const uploadTindakLanjut = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB
  },
});