import sharp from "sharp";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default async function resizeImage(req, res, next) {
  if (!req.file) return next();

  const filePath = path.join(__dirname, "../uploads/users", req.file.filename);

  try {
    await sharp(req.file.path)
      .resize(300, 300)
      .toFile(filePath);

    fs.unlinkSync(req.file.path); // hapus file asli

    next();
  } catch (err) {
    console.error("Resize error:", err);
    return res.status(500).json({ success: false, message: "Gagal resize foto" });
  }
}
