export function onlyUnit(...unitIds) {
  return (req, res, next) => {
    if (!unitIds.includes(req.user.unit_id)) {
      return res.status(403).json({ success: false, message: "Unit tidak berhak mengakses" });
    }
    next();
  };
}
