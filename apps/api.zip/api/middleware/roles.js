//D:\surat-menyurat-monorepo\apps\api\middleware\roles.js
export function onlyRole(...allowedRoles) {
  return (req, res, next) => {
    if (!allowedRoles.includes(req.user.role_slug)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }
    next();
  };
}
