import crypto from "crypto";

export function attachAuditContext(req, _res, next) {
  req.audit = {
    request_id: req.headers["x-request-id"] || crypto.randomUUID(),
    ip:
      req.headers["x-forwarded-for"]?.split(",")?.[0]?.trim() ||
      req.socket?.remoteAddress ||
      null,
    user_agent: req.headers["user-agent"] || null,
  };
  next();
}