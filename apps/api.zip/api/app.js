//D:\surat-menyurat-monorepo\apps\api\app.js
import express from "express";
import cookieParser from "cookie-parser";
import authRoutes from "./routes/auth.js";
import userRoutes from "./routes/users.js";
import suratRoutes from "./routes/surat_masuk.js";
import roleRoutes from "./routes/roles.js";
import unitRoutes from "./routes/units.js";
import permissionRoutes from "./routes/permissions.js";
import rolePermissionRoutes from "./routes/role_permissions.js";

const app = express();

app.use(express.json());
app.use(cookieParser());

app.use("/auth", authRoutes);
app.use("/roles", roleRoutes);
app.use("/units", unitRoutes);
app.use("/users", userRoutes);
app.use("/surat-masuk", suratRoutes);
app.use("/permissions", permissionRoutes);
app.use("/role-permissions", rolePermissionRoutes);

export default app;
