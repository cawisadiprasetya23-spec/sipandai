//D:\surat-menyurat-monorepo\apps\api\repositories\suratMasukTimeline.repository.js
import pool from "../db.js";

export async function getSuratMasukBasic(suratMasukId) {
  const [rows] = await pool.query(
    `
    SELECT
      sm.id,
      sm.tanggal_terima,
      sm.nomor_agenda,
      sm.nomor_surat,
      sm.asal_surat,
      sm.perihal,
      sm.file_surat,
      sm.unit_tujuan_id,
      u.name AS unit_name,
      sm.created_at,
      sm.updated_at
    FROM surat_masuk sm
    LEFT JOIN units u ON u.id = sm.unit_tujuan_id
    WHERE sm.id = ?
      AND sm.status_surat_id <> 5
    LIMIT 1
    `,
    [suratMasukId]
  );
  return rows[0] || null;
}

export async function listDisposisiWithTL(suratMasukId) {
  const [rows] = await pool.query(
    `
    SELECT
      d.id AS disposisi_id,
      d.surat_masuk_id,
      d.dari_unit_id,
      uf.name AS dari_unit_name,
      d.kepada_unit_id,
      ut.name AS kepada_unit_name,
      d.status,
      d.instruksi,
      d.catatan,
      d.due_date,
      d.created_at AS disposisi_created_at,
      d.updated_at AS disposisi_updated_at,

      tl.id AS tindak_lanjut_id,
      tl.uraian AS tl_uraian,
      tl.hasil AS tl_hasil,
      tl.tanggal_selesai AS tl_tanggal_selesai,
      tl.lampiran AS tl_lampiran,
      tl.created_at AS tl_created_at,
      tl.updated_at AS tl_updated_at
    FROM disposisi d
    LEFT JOIN units uf ON uf.id = d.dari_unit_id
    LEFT JOIN units ut ON ut.id = d.kepada_unit_id
    LEFT JOIN disposisi_tindak_lanjut tl
      ON tl.disposisi_id = d.id AND tl.deleted_at IS NULL
    WHERE d.surat_masuk_id = ?
      AND d.deleted_at IS NULL
    ORDER BY d.created_at ASC, d.id ASC
    `,
    [suratMasukId]
  );
  return rows;
}

// Optional: jika kamu punya tabel audit_logs dan ingin dipakai juga
export async function listAuditLogsByEntity(suratMasukId) {
  // Jika tabel/kolom berbeda, sesuaikan. Kalau belum ada event surat masuk, boleh return [].
  try {
    const [rows] = await pool.query(
      `
      SELECT
        id,
        action,
        entity_type,
        entity_id,
        created_at,
        actor_user_id,
        actor_unit_id,
        actor_unit_name
      FROM audit_logs
      WHERE (entity_type = 'surat_masuk' AND entity_id = ?)
      ORDER BY created_at ASC, id ASC
      `,
      [suratMasukId]
    );
    return rows;
  } catch (e) {
    return [];
  }
}