import pool from "../db.js";

let cachedColumns = null;

async function getCols() {
  if (cachedColumns) return cachedColumns;

  const dbName =
    process.env.DB_NAME || process.env.MYSQL_DATABASE || process.env.DATABASE;

  const [rows] = await pool.query(
    `
    SELECT COLUMN_NAME
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = ?
      AND TABLE_NAME = 'audit_logs'
    `,
    [dbName]
  );

  cachedColumns = new Set(rows.map((r) => r.COLUMN_NAME));
  return cachedColumns;
}

function pickMessageExpr(cols) {
  if (cols.has("message")) return "message";
  if (cols.has("description")) return "description";
  if (cols.has("detail")) return "detail";
  if (cols.has("keterangan")) return "keterangan";
  return "NULL";
}

export async function listLatest(limit = 10) {
  const cols = await getCols();
  const msgExpr = pickMessageExpr(cols);

  const sql = `
    SELECT
      ${cols.has("id") ? "id" : "NULL AS id"},
      ${cols.has("action") ? "action" : "NULL AS action"},
      ${cols.has("entity_type") ? "entity_type" : "NULL AS entity_type"},
      ${cols.has("entity_id") ? "entity_id" : "NULL AS entity_id"},
      ${msgExpr} AS message,
      ${msgExpr} AS description,
      ${cols.has("created_at") ? "created_at" : "NULL AS created_at"},
      NULL AS actor_name,
      NULL AS actor_unit_name
    FROM audit_logs
    ORDER BY created_at DESC, id DESC
    LIMIT ?
  `;

  const [rows] = await pool.query(sql, [limit]);
  return rows;
}