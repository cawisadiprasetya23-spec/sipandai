import pool from "../db.js";

export async function listDisposisiBySuratId(suratMasukId) {
  const [rows] = await pool.query(
    `
    SELECT
      d.id,
      d.surat_masuk_id,
      d.dari_unit_id,
      u_from.name AS dari_unit_name,
      d.kepada_unit_id,
      u_to.name AS kepada_unit_name,
      d.instruksi,
      d.catatan,
      d.due_date,
      d.status,
      d.created_at,
      d.updated_at
    FROM disposisi d
    LEFT JOIN units u_from ON u_from.id = d.dari_unit_id
    LEFT JOIN units u_to ON u_to.id = d.kepada_unit_id
    WHERE d.surat_masuk_id = ?
      AND d.deleted_at IS NULL
    ORDER BY d.created_at ASC, d.id ASC
    `,
    [suratMasukId]
  );
  return rows;
}

export async function getDisposisiById(id) {
  const [rows] = await pool.query(
    `SELECT * FROM disposisi WHERE id = ? AND deleted_at IS NULL LIMIT 1`,
    [id]
  );
  return rows[0] || null;
}

export async function updateDisposisiStatus({ id, status, catatan }) {
  const [result] = await pool.query(
    `
    UPDATE disposisi
    SET status = ?, catatan = COALESCE(?, catatan), updated_at = NOW()
    WHERE id = ? AND deleted_at IS NULL
    `,
    [status, catatan ?? null, id]
  );
  return result.affectedRows;
}