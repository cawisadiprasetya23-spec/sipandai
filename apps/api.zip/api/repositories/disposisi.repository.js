import pool from "../db.js";
import * as suratQueueRepo from "../repositories/suratMasukQueue.repository.js";

/**
 * =========================
 * DISPOSISI (existing)
 * =========================
 */

export async function listDisposisi({ search, surat_masuk_id, unitScope }) {
  // unitScope: { isAdmin: boolean, unitId: number|null }
  let sql = `
    SELECT d.*,
      sm.nomor_agenda, sm.nomor_surat, sm.asal_surat, sm.perihal,
      u_from.name AS dari_unit_name,
      u_to.name AS kepada_unit_name
    FROM disposisi d
    JOIN surat_masuk sm ON sm.id = d.surat_masuk_id
    LEFT JOIN units u_from ON u_from.id = d.dari_unit_id
    LEFT JOIN units u_to ON u_to.id = d.kepada_unit_id
    WHERE d.deleted_at IS NULL
  `;

  const params = [];

  // Filter by surat_masuk_id (optional)
  if (surat_masuk_id) {
    sql += " AND d.surat_masuk_id = ? ";
    params.push(surat_masuk_id);
  }

  // Search (optional)
  if (search) {
    sql +=
      " AND (sm.nomor_surat LIKE ? OR sm.asal_surat LIKE ? OR sm.perihal LIKE ? OR d.instruksi LIKE ?) ";
    const like = `%${search}%`;
    params.push(like, like, like, like);
  }

  // RBAC per unit:
  // - Admin: lihat semua
  // - Non-admin: hanya disposisi yang melibatkan unitnya (dari/kepada) ATAU surat masuk yang unit_tujuan_id = unitnya
  if (!unitScope?.isAdmin && unitScope?.unitId) {
    sql += `
      AND (
        d.dari_unit_id = ?
        OR d.kepada_unit_id = ?
        OR sm.unit_tujuan_id = ?
      )
    `;
    params.push(unitScope.unitId, unitScope.unitId, unitScope.unitId);
  }

  sql += " ORDER BY d.created_at DESC, d.id DESC ";

  const [rows] = await pool.query(sql, params);
  return rows;
}

export async function getDisposisiById(id) {
  const [rows] = await pool.query(
    `
    SELECT d.*,
      sm.nomor_agenda, sm.nomor_surat, sm.asal_surat, sm.perihal,
      u_from.name AS dari_unit_name,
      u_to.name AS kepada_unit_name
    FROM disposisi d
    JOIN surat_masuk sm ON sm.id = d.surat_masuk_id
    LEFT JOIN units u_from ON u_from.id = d.dari_unit_id
    LEFT JOIN units u_to ON u_to.id = d.kepada_unit_id
    WHERE d.id = ? AND d.deleted_at IS NULL
    LIMIT 1
    `,
    [id]
  );
  return rows[0] || null;
}

export async function createDisposisi(payload) {
  const {
    surat_masuk_id,
    dari_unit_id,
    dari_user_id,
    kepada_unit_id,
    kepada_user_id,
    instruksi,
    catatan,
    due_date,
    status,
  } = payload;

  const [result] = await pool.query(
    `
    INSERT INTO disposisi (
      surat_masuk_id, dari_unit_id, dari_user_id, kepada_unit_id, kepada_user_id,
      instruksi, catatan, due_date, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
    [
      surat_masuk_id,
      dari_unit_id,
      dari_user_id,
      kepada_unit_id,
      kepada_user_id,
      instruksi,
      catatan,
      due_date,
      status,
    ]
  );

  await suratQueueRepo.setUnitTujuanIfNull(payload.surat_masuk_id, payload.kepada_unit_id);
  await suratQueueRepo.recomputeAndUpdateDisposisiState(payload.surat_masuk_id);
  return result.insertId;
}

export async function updateDisposisi(id, payload) {
  const { kepada_unit_id, kepada_user_id, instruksi, catatan, due_date, status } = payload;

  const [result] = await pool.query(
    `
    UPDATE disposisi
    SET kepada_unit_id = ?, kepada_user_id = ?, instruksi = ?, catatan = ?, due_date = ?, status = ?
    WHERE id = ? AND deleted_at IS NULL
    `,
    [kepada_unit_id, kepada_user_id, instruksi, catatan, due_date, status, id]
  );

  return result.affectedRows;
}

export async function softDeleteDisposisi(id) {
  const [result] = await pool.query(
    `UPDATE disposisi SET deleted_at = NOW() WHERE id = ? AND deleted_at IS NULL`,
    [id]
  );
  return result.affectedRows;
}

/**
 * =========================
 * DASHBOARD (new)
 * =========================
 * Catatan:
 * - Disesuaikan dengan schema kamu:
 *   - disposisi.kepada_unit_id, disposisi.dari_unit_id, disposisi.status, disposisi.due_date (opsional)
 *   - surat_masuk.status_surat_id, surat_masuk.disposisi_state, surat_masuk.tanggal_terima, dst.
 */

export async function getAgendaCounts() {
  // "Agenda" di sini dibuat sederhana (contoh bulan ini + tanpa file) dan aman.
  // Kalau kamu punya definisi lain, tinggal sesuaikan SQL.
  const [rows] = await pool.query(
    `
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN sm.file_surat IS NULL OR sm.file_surat = '' THEN 1 ELSE 0 END) AS without_file
    FROM surat_masuk sm
    WHERE sm.status_surat_id <> 5
      AND sm.tanggal_terima >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
      AND sm.tanggal_terima <  DATE_ADD(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 1 MONTH)
    `
  );

  const r = rows[0] || {};
  return {
    total: Number(r.total || 0),
    without_file: Number(r.without_file || 0),
  };
}

export async function getDisposisiQueueCounts() {
  // Mengacu pada surat_masuk.disposisi_state yang sudah kamu punya:
  // not_disposed / in_disposition / completed (dll)
  const [rows] = await pool.query(
    `
    SELECT
      SUM(CASE WHEN sm.disposisi_state = 'not_disposed' THEN 1 ELSE 0 END) AS not_disposed,
      SUM(CASE WHEN sm.disposisi_state = 'in_disposition' THEN 1 ELSE 0 END) AS in_disposition,
      SUM(CASE WHEN sm.disposisi_state = 'completed' THEN 1 ELSE 0 END) AS completed
    FROM surat_masuk sm
    WHERE sm.status_surat_id <> 5
    `
  );

  const r = rows[0] || {};
  return {
    not_disposed: Number(r.not_disposed || 0),
    in_disposition: Number(r.in_disposition || 0),
    completed: Number(r.completed || 0),
  };
}

export async function getOverdueDisposisiCounts() {
  // Overdue hanya valid jika disposisi.due_date ada.
  // Jika kolom due_date belum terpakai, hasilnya 0 (aman).
  const [rows] = await pool.query(
    `
    SELECT
      SUM(
        CASE
          WHEN d.due_date IS NOT NULL
           AND d.due_date < CURDATE()
           AND (d.status IS NULL OR d.status NOT IN ('done','cancelled','completed'))
          THEN 1 ELSE 0
        END
      ) AS overdue_open
    FROM disposisi d
    WHERE d.deleted_at IS NULL
    `
  );

  const r = rows[0] || {};
  return { overdue_open: Number(r.overdue_open || 0) };
}

export async function listLatestSuratMasuk(limit = 5) {
  const [rows] = await pool.query(
    `
    SELECT
      sm.id,
      sm.tanggal_terima,
      sm.nomor_surat,
      sm.asal_surat,
      sm.perihal,
      sm.file_surat,
      sm.disposisi_state,
      sm.status_surat_id
    FROM surat_masuk sm
    WHERE sm.status_surat_id <> 5
    ORDER BY sm.tanggal_terima DESC, sm.id DESC
    LIMIT ?
    `,
    [limit]
  );
  return rows;
}

/**
 * Kabid Dashboard:
 * - Hanya disposisi yang "kepada_unit_id = unitId"
 * - Ini yang harus tampil sebagai "surat untuk unit saya"
 */
export async function getUnitWorkCounts(unitId) {
  const [rows] = await pool.query(
    `
    SELECT
      COUNT(*) AS assigned_open,
      SUM(
        CASE
          WHEN d.due_date IS NOT NULL
           AND d.due_date < CURDATE()
           AND (d.status IS NULL OR d.status NOT IN ('done','cancelled','completed'))
          THEN 1 ELSE 0
        END
      ) AS overdue_open,
      SUM(CASE WHEN d.status = 'returned' THEN 1 ELSE 0 END) AS returned_count
    FROM disposisi d
    JOIN surat_masuk sm ON sm.id = d.surat_masuk_id
    WHERE d.deleted_at IS NULL
      AND d.kepada_unit_id = ?
      AND sm.status_surat_id <> 5
      AND (d.status IS NULL OR d.status NOT IN ('done','cancelled','completed'))
    `,
    [unitId]
  );

  const r = rows[0] || {};
  return {
    assigned_open: Number(r.assigned_open || 0),
    overdue_open: Number(r.overdue_open || 0),
    returned_count: Number(r.returned_count || 0),
  };
}

export async function listUnitLatestDisposisi(unitId, limit = 5) {
  const [rows] = await pool.query(
    `
    SELECT
      d.id,
      d.surat_masuk_id,
      d.status,
      d.instruksi,
      d.catatan,
      d.dari_unit_id,
      d.kepada_unit_id,
      sm.tanggal_terima,
      sm.nomor_agenda,
      sm.nomor_surat,
      sm.asal_surat,
      sm.perihal,
      sm.file_surat,
      sm.disposisi_state,
      u_from.name AS dari_unit_name,
      u_to.name AS kepada_unit_name
    FROM disposisi d
    JOIN surat_masuk sm ON sm.id = d.surat_masuk_id
    LEFT JOIN units u_from ON u_from.id = d.dari_unit_id
    LEFT JOIN units u_to ON u_to.id = d.kepada_unit_id
    WHERE d.deleted_at IS NULL
      AND d.kepada_unit_id = ?
      AND sm.status_surat_id <> 5
    ORDER BY d.created_at DESC, d.id DESC
    LIMIT ?
    `,
    [unitId, limit]
  );

  return rows;
}