//D:\surat-menyurat-monorepo\apps\api\repositories\suratMasukQueue.repository.js
import pool from "../db.js";

// Query queue berdasarkan state + RBAC.
// - Admin/pimpinan: lihat semua
// - Non-admin: dibatasi unit (unit_tujuan_id) + keterlibatan disposisi
export async function listSuratMasukQueue({ state, search, unitScope }) {
  const params = [];
  let where = " WHERE sm.status_surat_id <> 5 ";

  if (search) {
    where += " AND (sm.nomor_surat LIKE ? OR sm.asal_surat LIKE ? OR sm.perihal LIKE ?) ";
    const like = `%${search}%`;
    params.push(like, like, like);
  }

  // RBAC unit (non-admin): hanya surat yang terkait unitnya
  if (!unitScope?.isAdmin && unitScope?.unitId) {
    where += `
      AND (
        sm.unit_tujuan_id = ?
        OR EXISTS (
          SELECT 1 FROM disposisi d
          WHERE d.surat_masuk_id = sm.id
            AND d.deleted_at IS NULL
            AND (d.dari_unit_id = ? OR d.kepada_unit_id = ?)
        )
      )
    `;
    params.push(unitScope.unitId, unitScope.unitId, unitScope.unitId);
  }

  // State filter
  if (state === "not_disposed") {
    where += `
      AND NOT EXISTS (
        SELECT 1 FROM disposisi d
        WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL
      )
    `;
  } else if (state === "in_disposition") {
    where += `
      AND EXISTS (
        SELECT 1 FROM disposisi d
        WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL
      )
      AND EXISTS (
        SELECT 1 FROM disposisi d
        WHERE d.surat_masuk_id = sm.id
          AND d.deleted_at IS NULL
          AND COALESCE(d.status,'sent') NOT IN ('done','cancelled')
      )
    `;
  } else if (state === "completed") {
    where += `
      AND EXISTS (
        SELECT 1 FROM disposisi d
        WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL
      )
      AND NOT EXISTS (
        SELECT 1 FROM disposisi d
        WHERE d.surat_masuk_id = sm.id
          AND d.deleted_at IS NULL
          AND COALESCE(d.status,'sent') NOT IN ('done','cancelled')
      )
    `;
  }

  const sql = `
    SELECT
      sm.id,
      sm.tanggal_terima,
      sm.nomor_agenda,
      sm.nomor_surat,
      sm.asal_surat,
      sm.perihal,
      sm.file_surat,        -- ✅ wajib untuk preview modal
      sm.unit_tujuan_id,
      u.name AS unit_name,

      (SELECT COUNT(*) FROM disposisi d
        WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL
      ) AS disposisi_count,

      (SELECT COUNT(*) FROM disposisi d
        WHERE d.surat_masuk_id = sm.id
          AND d.deleted_at IS NULL
          AND COALESCE(d.status,'sent') NOT IN ('done','cancelled')
      ) AS disposisi_open_count,

      (SELECT COUNT(*) FROM disposisi d
        WHERE d.surat_masuk_id = sm.id
          AND d.deleted_at IS NULL
          AND d.status = 'returned'
      ) AS returned_count,

      (SELECT COUNT(*) FROM disposisi d
        WHERE d.surat_masuk_id = sm.id
          AND d.deleted_at IS NULL
          AND COALESCE(d.status,'sent') NOT IN ('done','cancelled')
          AND d.due_date IS NOT NULL
          AND d.due_date < CURDATE()
      ) AS overdue_open_count,

      (SELECT MAX(d.created_at) FROM disposisi d
        WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL
      ) AS last_disposisi_at

    FROM surat_masuk sm
    LEFT JOIN units u ON u.id = sm.unit_tujuan_id
    ${where}
    ORDER BY sm.tanggal_terima DESC, sm.id DESC
  `;

  const [rows] = await pool.query(sql, params);
  return rows;
}

/**
 * Isi unit_tujuan_id surat masuk HANYA jika masih NULL.
 * Ini membuat kolom "Unit Tujuan" konsisten setelah disposisi pertama dibuat.
 */
export async function setUnitTujuanIfNull(suratMasukId, unitTujuanId) {
  const [result] = await pool.query(
    `
    UPDATE surat_masuk
    SET unit_tujuan_id = COALESCE(unit_tujuan_id, ?)
    WHERE id = ?
    `,
    [unitTujuanId, suratMasukId]
  );

  return result.affectedRows;
}

/**
 * Update surat_masuk.disposisi_state berdasarkan agregasi tabel disposisi.
 * Aman: jika kolom disposisi_state belum ada, fungsi tidak akan crash server (akan skip update).
 */
export async function recomputeAndUpdateDisposisiState(suratMasukId) {
  const [rows] = await pool.query(
    `
    SELECT
      (SELECT COUNT(*) FROM disposisi d
        WHERE d.surat_masuk_id = ? AND d.deleted_at IS NULL
      ) AS total,
      (SELECT COUNT(*) FROM disposisi d
        WHERE d.surat_masuk_id = ?
          AND d.deleted_at IS NULL
          AND COALESCE(d.status,'sent') NOT IN ('done','cancelled')
      ) AS openCount
    `,
    [suratMasukId, suratMasukId]
  );

  const total = rows?.[0]?.total ?? 0;
  const openCount = rows?.[0]?.openCount ?? 0;

  let state = "not_disposed";
  if (total > 0 && openCount > 0) state = "in_disposition";
  if (total > 0 && openCount === 0) state = "completed";

  // ✅ jangan bikin server mati kalau kolom disposisi_state belum ada
  try {
    await pool.query(`UPDATE surat_masuk SET disposisi_state = ? WHERE id = ?`, [
      state,
      suratMasukId,
    ]);
  } catch (err) {
    // ER_BAD_FIELD_ERROR: Unknown column 'disposisi_state'
    if (err?.code !== "ER_BAD_FIELD_ERROR") throw err;
  }

  return state;
}