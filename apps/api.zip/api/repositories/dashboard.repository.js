import pool from "../db.js";

/**
 * =========
 * UTIL
 * =========
 */
export async function getSuratMasukCountRange(startDate, endDate) {
  const [rows] = await pool.query(
    `
    SELECT COUNT(*) AS total
    FROM surat_masuk sm
    WHERE sm.status_surat_id <> 5
      AND sm.tanggal_terima >= ?
      AND sm.tanggal_terima < ?
    `,
    [startDate, endDate]
  );
  return Number(rows?.[0]?.total || 0);
}

export async function listSuratMasukWithoutFile(limit = 5) {
  const [rows] = await pool.query(
    `
    SELECT sm.id, sm.tanggal_terima, sm.nomor_surat, sm.asal_surat, sm.perihal, sm.file_surat
    FROM surat_masuk sm
    WHERE sm.status_surat_id <> 5
      AND (sm.file_surat IS NULL OR sm.file_surat = '')
    ORDER BY sm.tanggal_terima DESC, sm.id DESC
    LIMIT ?
    `,
    [limit]
  );
  return rows;
}

/**
 * =========
 * QUEUE (global surat_masuk.disposisi_state)
 * =========
 */
export async function getQueueCounts() {
  const [rows] = await pool.query(
    `
    SELECT
      SUM(CASE WHEN sm.disposisi_state = 'not_disposed' THEN 1 ELSE 0 END) AS not_disposed,
      SUM(CASE WHEN sm.disposisi_state = 'in_disposition' THEN 1 ELSE 0 END) AS in_disposition,
      SUM(CASE WHEN sm.disposisi_state = 'completed' THEN 1 ELSE 0 END) AS completed
    FROM surat_masuk sm
    WHERE sm.status_surat_id <> 5
    `
  );

  const r = rows[0] || {};
  return {
    not_disposed: Number(r.not_disposed || 0),
    in_disposition: Number(r.in_disposition || 0),
    completed: Number(r.completed || 0),
  };
}

export async function listNotDisposedLatest(limit = 5) {
  const [rows] = await pool.query(
    `
    SELECT sm.id, sm.tanggal_terima, sm.nomor_surat, sm.asal_surat, sm.perihal
    FROM surat_masuk sm
    WHERE sm.status_surat_id <> 5
      AND sm.disposisi_state = 'not_disposed'
    ORDER BY sm.tanggal_terima DESC, sm.id DESC
    LIMIT ?
    `,
    [limit]
  );
  return rows;
}

/**
 * =========
 * DISPOSISI overdue (butuh due_date; kalau null semua -> 0)
 * =========
 */
export async function getOverdueDisposisiCount() {
  const [rows] = await pool.query(
    `
    SELECT COUNT(*) AS total
    FROM disposisi d
    WHERE d.deleted_at IS NULL
      AND d.due_date IS NOT NULL
      AND d.due_date < CURDATE()
      AND (d.status IS NULL OR d.status NOT IN ('done','cancelled','completed'))
    `
  );
  return Number(rows?.[0]?.total || 0);
}

export async function listOverdueDisposisiLatest(limit = 5) {
  const [rows] = await pool.query(
    `
    SELECT
      d.id,
      d.surat_masuk_id,
      d.due_date,
      d.status,
      sm.nomor_surat,
      sm.asal_surat,
      sm.perihal,
      u_to.name AS kepada_unit_name
    FROM disposisi d
    JOIN surat_masuk sm ON sm.id = d.surat_masuk_id
    LEFT JOIN units u_to ON u_to.id = d.kepada_unit_id
    WHERE d.deleted_at IS NULL
      AND d.due_date IS NOT NULL
      AND d.due_date < CURDATE()
      AND sm.status_surat_id <> 5
      AND (d.status IS NULL OR d.status NOT IN ('done','cancelled','completed'))
    ORDER BY d.due_date ASC, d.id DESC
    LIMIT ?
    `,
    [limit]
  );
  return rows;
}

/**
 * =========
 * UNIT / PERSONAL DISPOSISI (Sekretariat & Kabid)
 * =========
 */
export async function getOpenDisposisiCountForUnit(unitId) {
  const [rows] = await pool.query(
    `
    SELECT COUNT(*) AS total
    FROM disposisi d
    JOIN surat_masuk sm ON sm.id = d.surat_masuk_id
    WHERE d.deleted_at IS NULL
      AND d.kepada_unit_id = ?
      AND sm.status_surat_id <> 5
      AND (d.status IS NULL OR d.status NOT IN ('done','cancelled','completed'))
    `,
    [unitId]
  );
  return Number(rows?.[0]?.total || 0);
}

export async function getOpenDisposisiCountForUser(userId) {
  const [rows] = await pool.query(
    `
    SELECT COUNT(*) AS total
    FROM disposisi d
    JOIN surat_masuk sm ON sm.id = d.surat_masuk_id
    WHERE d.deleted_at IS NULL
      AND d.kepada_user_id = ?
      AND sm.status_surat_id <> 5
      AND (d.status IS NULL OR d.status NOT IN ('done','cancelled','completed'))
    `,
    [userId]
  );
  return Number(rows?.[0]?.total || 0);
}

export async function listLatestDisposisiForUnit(unitId, limit = 5) {
  const [rows] = await pool.query(
    `
    SELECT
      d.id,
      d.surat_masuk_id,
      d.status,
      d.instruksi,
      d.catatan,
      sm.tanggal_terima,
      sm.nomor_surat,
      sm.asal_surat,
      sm.perihal
    FROM disposisi d
    JOIN surat_masuk sm ON sm.id = d.surat_masuk_id
    WHERE d.deleted_at IS NULL
      AND d.kepada_unit_id = ?
      AND sm.status_surat_id <> 5
    ORDER BY d.id DESC
    LIMIT ?
    `,
    [unitId, limit]
  );
  return rows;
}

export async function listLatestDisposisiForUser(userId, limit = 5) {
  const [rows] = await pool.query(
    `
    SELECT
      d.id,
      d.surat_masuk_id,
      d.status,
      d.instruksi,
      d.catatan,
      sm.tanggal_terima,
      sm.nomor_surat,
      sm.asal_surat,
      sm.perihal
    FROM disposisi d
    JOIN surat_masuk sm ON sm.id = d.surat_masuk_id
    WHERE d.deleted_at IS NULL
      AND d.kepada_user_id = ?
      AND sm.status_surat_id <> 5
    ORDER BY d.id DESC
    LIMIT ?
    `,
    [userId, limit]
  );
  return rows;
}

/**
 * =========
 * Kabid extras
 * =========
 */
export async function getReturnedCountForUnit(unitId) {
  const [rows] = await pool.query(
    `
    SELECT COUNT(*) AS total
    FROM disposisi d
    WHERE d.deleted_at IS NULL
      AND d.kepada_unit_id = ?
      AND d.status = 'returned'
    `,
    [unitId]
  );
  return Number(rows?.[0]?.total || 0);
}

export async function getOverdueCountForUnit(unitId) {
  const [rows] = await pool.query(
    `
    SELECT COUNT(*) AS total
    FROM disposisi d
    WHERE d.deleted_at IS NULL
      AND d.kepada_unit_id = ?
      AND d.due_date IS NOT NULL
      AND d.due_date < CURDATE()
      AND (d.status IS NULL OR d.status NOT IN ('done','cancelled','completed'))
    `,
    [unitId]
  );
  return Number(rows?.[0]?.total || 0);
}