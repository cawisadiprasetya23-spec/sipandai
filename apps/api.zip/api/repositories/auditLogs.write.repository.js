import pool from "../db.js";

export async function insertAuditLog({
  actor_user_id = null,
  actor_unit_id = null,
  action,
  entity_type,
  entity_id = null,
  request_id = null,
  ip = null,
  user_agent = null,
  message = null,
  metadata = null,
  created_at = null,
}) {
  const sql = `
    INSERT INTO audit_logs (
      actor_user_id,
      actor_unit_id,
      action,
      entity_type,
      entity_id,
      request_id,
      ip,
      user_agent,
      message,
      metadata
      ${created_at ? ", created_at" : ""}
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?${created_at ? ", ?" : ""})
  `;

  const params = [
    actor_user_id,
    actor_unit_id,
    action,
    entity_type,
    entity_id,
    request_id,
    ip,
    user_agent,
    message,
    metadata ? JSON.stringify(metadata) : null,
  ];

  if (created_at) params.push(created_at);

  const [result] = await pool.query(sql, params);
  return result.insertId;
}