import pool from "../db.js";

export async function getByDisposisiId(disposisiId) {
  const [rows] = await pool.query(
    `
    SELECT *
    FROM disposisi_tindak_lanjut
    WHERE disposisi_id = ?
      AND deleted_at IS NULL
    LIMIT 1
    `,
    [disposisiId]
  );
  return rows[0] || null;
}

export async function create({ disposisi_id, uraian, hasil, tanggal_selesai, lampiran, dibuat_oleh_user_id, dibuat_oleh_unit_id }) {
  const [result] = await pool.query(
    `
    INSERT INTO disposisi_tindak_lanjut
      (disposisi_id, uraian, hasil, tanggal_selesai, lampiran, dibuat_oleh_user_id, dibuat_oleh_unit_id)
    VALUES
      (?, ?, ?, ?, ?, ?, ?)
    `,
    [disposisi_id, uraian, hasil, tanggal_selesai, lampiran, dibuat_oleh_user_id, dibuat_oleh_unit_id]
  );
  return result.insertId;
}

export async function updateByDisposisiId(disposisiId, { uraian, hasil, tanggal_selesai, lampiran }) {
  const [result] = await pool.query(
    `
    UPDATE disposisi_tindak_lanjut
    SET
      uraian = ?,
      hasil = ?,
      tanggal_selesai = ?,
      lampiran = ?,
      updated_at = NOW()
    WHERE disposisi_id = ?
      AND deleted_at IS NULL
    `,
    [uraian, hasil, tanggal_selesai, lampiran, disposisiId]
  );
  return result.affectedRows;
}

export async function softDeleteByDisposisiId(disposisiId) {
  const [result] = await pool.query(
    `
    UPDATE disposisi_tindak_lanjut
    SET deleted_at = NOW(), updated_at = NOW()
    WHERE disposisi_id = ?
      AND deleted_at IS NULL
    `,
    [disposisiId]
  );
  return result.affectedRows;
}

export async function setLampiranByDisposisiId(disposisiId, lampiran) {
  const [result] = await pool.query(
    `
    UPDATE disposisi_tindak_lanjut
    SET lampiran = ?, updated_at = NOW()
    WHERE disposisi_id = ?
      AND deleted_at IS NULL
    `,
    [lampiran, disposisiId]
  );
  return result.affectedRows;
}