import * as service from "../services/disposisi.service.js";

export async function list(req, res) {
  try {
    const data = await service.list(req);
    res.json({ success: true, data });
  } catch (err) {
    console.error("DISPOSISI LIST ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}

export async function detail(req, res) {
  try {
    const id = Number(req.params.id);
    const data = await service.detail(req, id);
    if (!data) return res.status(404).json({ success: false, message: "Disposisi tidak ditemukan" });
    res.json({ success: true, data });
  } catch (err) {
    console.error("DISPOSISI DETAIL ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}

export async function create(req, res) {
  try {
    const data = await service.create(req, req.body);
    res.json({ success: true, message: "Berhasil membuat disposisi", data });
  } catch (err) {
    console.error("DISPOSISI CREATE ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}

export async function update(req, res) {
  try {
    const id = Number(req.params.id);
    const result = await service.update(req, id, req.body);
    if (result.notFound) return res.status(404).json({ success: false, message: "Disposisi tidak ditemukan" });
    res.json({ success: true, message: "Berhasil mengubah disposisi" });
  } catch (err) {
    console.error("DISPOSISI UPDATE ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}

export async function remove(req, res) {
  try {
    const id = Number(req.params.id);
    const result = await service.remove(req, id);
    if (result.notFound) return res.status(404).json({ success: false, message: "Disposisi tidak ditemukan" });
    res.json({ success: true, message: "Berhasil menghapus disposisi" });
  } catch (err) {
    console.error("DISPOSISI DELETE ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}