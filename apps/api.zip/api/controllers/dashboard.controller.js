import * as service from "../services/dashboard.service.js";

export async function getSummary(req, res) {
  try {
    const data = await service.getDashboardSummary(req);
    res.json({ success: true, data });
  } catch (err) {
    console.error("DASHBOARD SUMMARY ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}