import * as service from "../services/disposisiMonitoring.service.js";

export async function getBySurat(req, res) {
  try {
    const data = await service.getMonitoringBySurat(req, req.params.suratMasukId);
    res.json({ success: true, data });
  } catch (err) {
    console.error("MONITORING ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}

export async function updateStatus(req, res) {
  try {
    const result = await service.setStatus(req, {
      id: req.params.id,
      status: req.body?.status,
      catatan: req.body?.catatan,
    });

    if (result.notFound) {
      return res.status(404).json({ success: false, message: "Disposisi tidak ditemukan" });
    }

    res.json({ success: true, message: "Status disposisi berhasil diubah", data: result });
  } catch (err) {
    console.error("UPDATE STATUS ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}