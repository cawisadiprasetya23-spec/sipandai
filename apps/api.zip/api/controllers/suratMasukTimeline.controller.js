//D:\surat-menyurat-monorepo\apps\api\controllers\suratMasukTimeline.controller.js
import * as service from "../services/suratMasukTimeline.service.js";

export async function getTimeline(req, res) {
  try {
    const result = await service.getTimeline(req, req.params.id);
    if (result.notFound) {
      return res.status(404).json({ success: false, message: "Surat masuk tidak ditemukan" });
    }
    res.json({ success: true, data: result });
  } catch (err) {
    console.error("TIMELINE ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}