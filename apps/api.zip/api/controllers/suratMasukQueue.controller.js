//D:\surat-menyurat-monorepo\apps\api\controllers\suratMasukQueue.controller.js
import * as service from "../services/suratMasukQueue.service.js";

export async function listQueue(req, res) {
  try {
    const data = await service.listQueue(req);
    res.json({ success: true, data });
  } catch (err) {
    console.error("SURAT MASUK QUEUE ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}