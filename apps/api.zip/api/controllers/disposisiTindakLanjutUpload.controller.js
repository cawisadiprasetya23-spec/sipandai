import * as service from "../services/disposisiTindakLanjutUpload.service.js";

export async function uploadLampiran(req, res) {
  try {
    if (!req.file?.filename) {
      return res.status(400).json({ success: false, message: "File lampiran wajib diupload" });
    }

    const result = await service.uploadLampiran(req, req.params.disposisiId, req.file.filename);
    res.json({ success: true, message: "Lampiran berhasil diupload", data: result });
  } catch (err) {
    console.error("UPLOAD TL ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}