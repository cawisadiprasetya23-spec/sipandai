import * as service from "../services/disposisiTindakLanjut.service.js";

export async function get(req, res) {
  try {
    const result = await service.get(req, req.params.disposisiId);
    if (result.notFound) return res.status(404).json({ success: false, message: "Disposisi tidak ditemukan" });
    res.json({ success: true, data: result });
  } catch (err) {
    console.error("TL GET ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}

export async function upsert(req, res) {
  try {
    const result = await service.upsert(req, req.params.disposisiId, req.body);
    if (result.notFound) return res.status(404).json({ success: false, message: "Disposisi tidak ditemukan" });
    res.json({ success: true, message: "Tindak lanjut tersimpan", data: result });
  } catch (err) {
    console.error("TL UPSERT ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}

export async function remove(req, res) {
  try {
    const result = await service.remove(req, req.params.disposisiId);
    if (result.notFound) return res.status(404).json({ success: false, message: "Disposisi tidak ditemukan" });
    res.json({ success: true, message: "Tindak lanjut dihapus", data: result });
  } catch (err) {
    console.error("TL DELETE ERROR:", err);
    res.status(err.status || 500).json({ success: false, message: err.message || "Server error" });
  }
}