export function pickColumn(input, allowMap, fallbackKey) {
  const key = String(input || "").toLowerCase();
  return allowMap[key] || allowMap[fallbackKey];
}