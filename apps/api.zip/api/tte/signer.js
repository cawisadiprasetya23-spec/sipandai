import fs from "fs";
import path from "path";
import signer from "node-signpdf"; // atau modul TTE lokal lain

export async function signPDF(inputPath, outputPath) {
  const pdfBuffer = fs.readFileSync(inputPath);
  const p12Buffer = fs.readFileSync(path.join(__dirname, "certs", "kepala_badan.p12"));

  const signed = signer.sign(pdfBuffer, p12Buffer);
  fs.writeFileSync(outputPath, signed);
}
