// ========================================
// ENVIRONMENT
// ========================================
import dotenv from "dotenv";
dotenv.config();

// ========================================
// CORE IMPORTS
// ========================================
import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

// ========================================
// ROUTES
// ========================================
import authRoutes from "./routes/auth.js";
import roleRoutes from "./routes/roles.js";
import userRoutes from "./routes/users.js";
import unitRoutes from "./routes/units.js";
import auditLogRoutes from "./routes/audit-logs.js";

import suratClassificationsRouter from "./routes/surat_classifications.js";
import sifatSuratRoutes from "./routes/sifat_surat.js";
import pejabatTTDRoutes from "./routes/pejabat_penandatangan.js";
import jenisSuratRoutes from "./routes/jenis_surat.js";
import mediaSuratRoutes from "./routes/media_surat.js";
import statusSuratRoutes from "./routes/status_surat.js";

import suratMasukRoutes from "./routes/surat_masuk.js";
import suratMasukQueueRoutes from "./routes/surat_masuk_queue.js";
import suratMasukTimelineRoutes from "./routes/surat_masuk_timeline.js";

import suratKeluarRoutes from "./routes/surat_keluar.js";

import disposisiRoutes from "./routes/disposisi.js";
import disposisiMonitoringRoutes from "./routes/disposisi_monitoring.js";
import disposisiTindakLanjutRoutes from "./routes/disposisi_tindak_lanjut.js";
import disposisiTindakLanjutUploadRoutes from "./routes/disposisi_tindak_lanjut_upload.js";

import dashboardRoutes from "./routes/dashboard.js";

// ========================================
// MIDDLEWARE
// ========================================
import { attachAuditContext } from "./middleware/auditContext.js";

// ========================================
// PATH SETUP
// ========================================
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ========================================
// EXPRESS APP
// ========================================
const app = express();

// ----------------------------------------
// CORE MIDDLEWARE
// ----------------------------------------
app.disable("etag");
app.use(express.json());
app.use(attachAuditContext);

// ----------------------------------------
// CORS
// ----------------------------------------
app.use(
  cors({
    origin: "http://localhost:3000",
  })
);

// ----------------------------------------
// STATIC FILES
// ----------------------------------------
// Semua file di apps/api/uploads bisa diakses via:
// http://localhost:5000/uploads/<filename>
// http://localhost:5000/uploads/tindak-lanjut/<filename>
// http://localhost:5000/uploads/users/<filename>
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ========================================
// API ROUTES
// ========================================

// Auth & Users
app.use("/api/auth", authRoutes);
app.use("/api/roles", roleRoutes);
app.use("/api/units", unitRoutes);
app.use("/api/users", userRoutes);
app.use("/api/audit-logs", auditLogRoutes);

// Master Data Surat
app.use("/api/surat-classifications", suratClassificationsRouter);
app.use("/api/sifat-surat", sifatSuratRoutes);
app.use("/api/pejabat-ttd", pejabatTTDRoutes);
app.use("/api/jenis-surat", jenisSuratRoutes);
app.use("/api/media-surat", mediaSuratRoutes);
app.use("/api/status-surat", statusSuratRoutes);

// Surat Masuk (grouped)
app.use("/api/surat-masuk", suratMasukRoutes);
app.use("/api/surat-masuk/queue", suratMasukQueueRoutes);
app.use("/api/surat-masuk/timeline", suratMasukTimelineRoutes);

// Surat Keluar (grouped)
app.use("/api/surat-keluar", suratKeluarRoutes);

// Disposisi (grouped)
app.use("/api/disposisi", disposisiRoutes);
app.use("/api/disposisi", disposisiMonitoringRoutes);
app.use("/api/disposisi", disposisiTindakLanjutRoutes);
app.use("/api/disposisi", disposisiTindakLanjutUploadRoutes);

// Dashboard
app.use("/api/dashboard", dashboardRoutes);

// ========================================
// 404 HANDLER
// ========================================
app.use((req, res) => {
  res.status(404).json({ success: false, message: "Not Found" });
});

// ========================================
// SERVER START
// ========================================
const port = Number(process.env.PORT || 5000);
app.listen(port, () => {
  console.log(`API running at http://localhost:${port}`);
});
