// apps/api/routes/auth.js
import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pool from "../db.js";
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const [rows] = await pool.query(
      "SELECT * FROM users WHERE username = ? LIMIT 1",
      [username]
    );

    if (!rows.length) {
      return res.status(401).json({ success: false, message: "User not found" });
    }

    const user = rows[0];

    // Pastikan kolom password_hash ada
    if (!user.password_hash) {
      return res.status(500).json({
        success: false,
        message: "Password hash missing in database",
      });
    }

    // 🔥 CEK PASSWORD HASH ATAU PLAIN
    let passwordValid = false;

    if (
      user.password_hash.startsWith("$2a$") ||
      user.password_hash.startsWith("$2b$")
    ) {
      // Password HASHED → gunakan bcrypt
      passwordValid = await bcrypt.compare(password, user.password_hash);
    } else {
      // Password PLAIN → bandingkan langsung
      passwordValid = user.password_hash === password;
    }

    if (!passwordValid) {
      return res.status(401).json({ success: false, message: "Wrong password" });
    }

    // 🔥 BUAT JWT VALID
    const token = jwt.sign(
      {
        id: user.id,
        username: user.username,
        name: user.full_name,
        role_id: user.role_id,
        unit_id: user.unit_id,
      },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    // Jangan kirim password ke frontend
    delete user.password_hash;

    res.json({
      success: true,
      token,
      user,
    });

  } catch (err) {
    console.error("LOGIN ERROR:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
});

router.get("/me", authenticate, (req, res) => {
  return res.json({ success: true, user: req.user });
});

export default router;
