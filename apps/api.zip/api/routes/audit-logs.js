import express from "express";
import { authenticate } from "../middleware/auth.js";
import * as auditRepo from "../repositories/auditLogs.repository.js";

const router = express.Router();

router.get("/entity/:entityType/:entityId", authenticate, async (req, res) => {
  try {
    const { entityType, entityId } = req.params;
    const data = await auditRepo.listByEntity({
      entityType,
      entityId: Number(entityId),
    });
    res.json({ success: true, data });
  } catch (e) {
    console.error("audit logs error:", e);
    res.status(500).json({ success: false, message: e.message || "Server error" });
  }
});

export default router;