import express from "express";
import pool from "../db.js";
import bcrypt from "bcryptjs";
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

// ============================
// GET ALL USERS
// ============================
router.get("/", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT u.id,
             u.username,
             u.full_name,
             u.nip,
             u.active,
             u.photo,
             u.role_id,
             u.unit_id,
             r.name AS role_name,
             un.name AS unit_name
      FROM users u
      LEFT JOIN roles r ON u.role_id = r.id
      LEFT JOIN units un ON u.unit_id = un.id
      ORDER BY u.id ASC
    `);

    res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET /api/users:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// ============================
// CREATE USER
// ============================
router.post("/", authenticate, async (req, res) => {
  const actor = req.user;
  const { username, password, full_name, role_id, unit_id } = req.body;

  try {
    // ===========================
    // VALIDATION
    // ===========================
    const uname = String(username || "").trim();
    const fname = String(full_name || "").trim();
    const pwd = String(password || "");

    if (!uname) {
      return res.status(400).json({ success: false, message: "Username wajib diisi" });
    }
    if (!pwd || pwd.length < 6) {
      return res.status(400).json({ success: false, message: "Password minimal 6 karakter" });
    }
    if (!fname) {
      return res.status(400).json({ success: false, message: "Nama lengkap wajib diisi" });
    }
    if (!role_id) {
      return res.status(400).json({ success: false, message: "Role wajib dipilih" });
    }
    // unit_id boleh null tergantung bisnis, tapi kalau wajib, aktifkan:
    // if (!unit_id) return res.status(400).json({ success: false, message: "Unit wajib dipilih" });

    // ===========================
    // CHECK DUPLICATE USERNAME
    // ===========================
    const [exists] = await pool.query(`SELECT id FROM users WHERE username = ? LIMIT 1`, [uname]);
    if (exists.length > 0) {
      return res.status(409).json({ success: false, message: "Username sudah digunakan" });
    }

    // ===========================
    // HASH PASSWORD (bcrypt)
    // ===========================
    const passwordHash = await bcrypt.hash(pwd, 10);

    // ===========================
    // INSERT USER
    // ===========================
    const [result] = await pool.query(
      `
      INSERT INTO users (username, password_hash, full_name, role_id, unit_id)
      VALUES (?, ?, ?, ?, ?)
      `,
      [uname, passwordHash, fname, role_id, unit_id ?? null]
    );

    const newUserId = result.insertId;

    // ===========================
    // AUDIT LOG
    // ===========================
    await insertAuditLog({
      actor_user_id: actor?.id ?? null,
      actor_unit_id: actor?.unit_id ?? null,
      action: "CREATE_USER",
      entity_type: "user",
      entity_id: newUserId,
      request_id: req.audit?.request_id ?? null,
      ip: req.audit?.ip ?? null,
      user_agent: req.audit?.user_agent ?? null,
      message: `Membuat user baru: ${uname}`,
      metadata: {
        username: uname,
        full_name: fname,
        role_id,
        unit_id: unit_id ?? null,
      },
    });

    return res.json({ success: true, data: { id: newUserId } });
  } catch (e) {
    console.error("ERROR POST /api/users:", e);
    return res.status(500).json({ success: false, message: e.message || "Server error" });
  }
});

// ============================
// UPDATE USER
// ============================
router.put("/:id", authenticate, async (req, res) => {
  const actorId = req.user.id;
  const targetId = req.params.id;

  const { username, full_name, nip, role_id, unit_id, active, password } = req.body;

  try {
    // Jika password dikirim → validasi + hash
    if (password && password.trim() !== "") {
      if (password.length < 8) {
        return res.status(400).json({
          success: false,
          message: "Password minimal 8 karakter",
        });
      }

      const hashedPassword = await bcrypt.hash(password, 10);

      await pool.query(
        `UPDATE users 
         SET username = ?, full_name = ?, nip = ?, role_id = ?, unit_id = ?, active = ?, password_hash = ?
         WHERE id = ?`,
        [
          username,
          full_name || null,
          nip || null,
          role_id,
          unit_id || null,
          active ?? 1,
          hashedPassword,
          targetId,
        ]
      );

      // AUDIT LOG
      await pool.query(
        `INSERT INTO audit_logs (actor_id, action, target_user_id, description)
         VALUES (?, 'UPDATE_USER_PASSWORD', ?, ?)`,
        [actorId, targetId, `Mengubah password user: ${username}`]
      );
    } else {
      // Tanpa password
      await pool.query(
        `UPDATE users 
        SET username = ?, full_name = ?, nip = ?, role_id = ?, unit_id = ?, active = ?
        WHERE id = ?`,
        [
          username,
          full_name || null,
          nip || null,
          role_id,
          unit_id || null,
          active ?? 1,
          targetId,
        ]
      );

      // AUDIT LOG
      await pool.query(
        `INSERT INTO audit_logs (actor_id, action, target_user_id, description)
         VALUES (?, 'UPDATE_USER', ?, ?)`,
        [actorId, targetId, `Mengubah data user: ${username}`]
      );
    }

    res.json({ success: true });
  } catch (err) {
    console.error("ERROR PUT /api/users:", err);
    res.status(500).json({ success: false, message: "Gagal update user" });
  }
});

// ============================
// DELETE USER
// ============================
router.delete("/:id", authenticate, async (req, res) => {
  const actorId = req.user.id;
  const targetId = req.params.id;

  try {
    await pool.query("DELETE FROM users WHERE id = ?", [targetId]);

    // AUDIT LOG
    await pool.query(
      `INSERT INTO audit_logs (actor_id, action, target_user_id, description)
       VALUES (?, 'DELETE_USER', ?, ?)`,
      [actorId, targetId, `Menghapus user ID ${targetId}`]
    );

    res.json({ success: true });
  } catch (err) {
    console.error("ERROR DELETE /api/users:", err);
    res.status(500).json({ success: false, message: "Gagal hapus user" });
  }
});

export default router;
