import express from "express";
import pool from "../db.js";
import { authenticate } from "../middleware/auth.js";
import { onlyRole } from "../middleware/roles.js";

const router = express.Router();

// =========================
// GET PERMISSIONS BY ROLE
// =========================
router.get("/role/:role_id", authenticate, onlyRole("superadmin"), async (req, res) => {
  const { role_id } = req.params;

  try {
    const [rows] = await pool.query(
      `SELECT 
         rp.id,
         rp.role_id,
         rp.permission_id,
         p.name AS permission_name
       FROM role_permissions rp
       LEFT JOIN permissions p ON rp.permission_id = p.id
       WHERE rp.role_id = ?`,
      [role_id]
    );

    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// =========================
// ASSIGN PERMISSION TO ROLE
// =========================
router.post("/", authenticate, onlyRole("superadmin"), async (req, res) => {
  const { role_id, permission_id } = req.body;

  if (!role_id || !permission_id)
    return res.status(400).json({ success: false, message: "role_id & permission_id wajib diisi" });

  try {
    const [result] = await pool.query(
      `INSERT INTO role_permissions (role_id, permission_id)
       VALUES (?, ?)`,
      [role_id, permission_id]
    );

    res.json({ success: true, id: result.insertId });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// =========================
// DELETE ROLE_PERMISSION (UNASSIGN)
// =========================
router.delete("/:id", authenticate, onlyRole("superadmin"), async (req, res) => {
  const { id } = req.params;

  try {
    await pool.query("DELETE FROM role_permissions WHERE id = ?", [id]);
    res.json({ success: true, message: "Permission berhasil dicabut dari role" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

export default router;
