import express from "express";
import db from "../db.js"; // sesuaikan path DB kamu
import multer from "multer";
import path from "path";

const router = express.Router();

// =============================
// UPLOAD SETUP
// =============================
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/ttd");
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + ext);
  },
});

const upload = multer({ storage });

// =============================
// GET LIST
// =============================
router.get("/", async (req, res) => {
  const { search } = req.query;

  let sql = `
    SELECT p.*, u.name AS unit_name
    FROM pejabat_penandatangan p
    LEFT JOIN units u ON u.id = p.unit_kerja_id
    WHERE 1=1
  `;
  const params = [];

  if (search) {
    sql += " AND (p.nama LIKE ? OR p.jabatan LIKE ? OR p.nip LIKE ?)";
    const like = `%${search}%`;
    params.push(like, like, like);
  }

  sql += " ORDER BY p.nama ASC";

  try {
    const [rows] = await db.query(sql, params);
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET /api/pejabat-ttd:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});


// =============================
// GET DETAIL
// =============================
router.get("/:id", async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT * FROM pejabat_penandatangan WHERE id = ?",
      [req.params.id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Data tidak ditemukan" });
    }

    res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal mengambil data" });
  }
});

// =============================
// CREATE
// =============================
router.post("/", async (req, res) => {
  const { nama, nip, jabatan, unit_kerja_id, aktif } = req.body;

  if (!nama || !jabatan || !unit_kerja_id) {
    return res.status(400).json({ success: false, message: "Nama, jabatan, dan unit kerja wajib diisi" });
  }

  try {
    const [result] = await db.query(
      `INSERT INTO pejabat_penandatangan 
       (nama, nip, jabatan, unit_kerja_id, aktif)
       VALUES (?, ?, ?, ?, ?)`,
      [nama, nip || null, jabatan, unit_kerja_id, aktif !== undefined ? !!aktif : true]
    );

    res.json({ success: true, data: { id: result.insertId } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal menyimpan data" });
  }
});

// =============================
// UPDATE
// =============================
router.put("/:id", async (req, res) => {
  const { nama, nip, jabatan, unit_kerja_id, aktif } = req.body;

  if (!nama || !jabatan || !unit_kerja_id) {
    return res.status(400).json({ success: false, message: "Nama, jabatan, dan unit kerja wajib diisi" });
  }

  try {
    await db.query(
      `UPDATE pejabat_penandatangan
       SET nama = ?, nip = ?, jabatan = ?, unit_kerja_id = ?, aktif = ?
       WHERE id = ?`,
      [nama, nip || null, jabatan, unit_kerja_id, !!aktif, req.params.id]
    );

    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal mengubah data" });
  }
});

// =============================
// DELETE (soft delete)
// =============================
router.delete("/:id", async (req, res) => {
  try {
    await db.query(
      "UPDATE pejabat_penandatangan SET aktif = 0 WHERE id = ?",
      [req.params.id]
    );
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal menghapus data" });
  }
});

// =============================
// UPLOAD TTD
// =============================
router.post("/upload-ttd/:id", upload.single("file"), async (req, res) => {
  try {
    await db.query(
      "UPDATE pejabat_penandatangan SET tanda_tangan = ? WHERE id = ?",
      [req.file.filename, req.params.id]
    );
    res.json({ success: true, file: req.file.filename });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal upload tanda tangan" });
  }
});

// =============================
// UPLOAD STEMPEL
// =============================
router.post("/upload-stempel/:id", upload.single("file"), async (req, res) => {
  try {
    await db.query(
      "UPDATE pejabat_penandatangan SET cap_stempel = ? WHERE id = ?",
      [req.file.filename, req.params.id]
    );
    res.json({ success: true, file: req.file.filename });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal upload stempel" });
  }
});

export default router;
