//D:\surat-menyurat-monorepo\apps\api\routes\surat_masuk.js
import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import pool from "../db.js";
import { authenticate } from "../middleware/auth.js";
import jwt from "jsonwebtoken";
import dayjs from "dayjs";

const router = express.Router();

// ===========================
// MULTER CONFIG
// ===========================
const uploadDir = "uploads";
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, "surat-" + unique + ext);
  },
});

const upload = multer({ storage });

// ===========================
// HELPERS
// ===========================
const toNull = (v) => {
  if (v === undefined || v === null) return null;
  if (typeof v === "string") {
    const s = v.trim();
    if (s === "" || s === "null" || s === "undefined") return null;
    return s;
  }
  return v;
};

const toIntOrNull = (v) => {
  v = toNull(v);
  if (v === null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

// Validasi nama file agar tidak bisa path traversal: ../../etc/passwd
const isSafeFilename = (name) => {
  if (!name) return false;
  if (name.includes("..")) return false;
  if (name.includes("/") || name.includes("\\")) return false;
  return true;
};

// Middleware auth khusus untuk link preview/download (mendukung header atau query token)
const authenticateFileAccess = (req, res, next) => {
  // 1) normal header-based auth (untuk fetch)
  const header = req.headers.authorization || "";
  const headerToken = header.startsWith("Bearer ") ? header.slice(7) : null;

  // 2) query token (untuk <a target="_blank">)
  const queryToken = req.query.token;

  const token = headerToken || queryToken;

  if (!token) {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }

  try {
    // Sesuaikan secret dengan sistem kamu (umumnya JWT_SECRET)
    const secret = process.env.JWT_SECRET || process.env.SECRET_KEY;
    if (!secret) {
      return res
        .status(500)
        .json({ success: false, message: "Server misconfigured (missing JWT secret)" });
    }

    const decoded = jwt.verify(token, secret);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }
};

// Helper RBAC: tentukan admin/pimpinan
const isAdminRole = (user) => {
  const role = (user?.role || user?.role_name || "").toLowerCase();
  return ["admin", "superadmin", "kepala_badan", "pimpinan"].includes(role);
};

router.get("/stats", authenticate, async (req, res) => {
  try {
    const [rowsState] = await pool.query(`
      SELECT 
        sm.disposisi_state,
        COUNT(*) AS total
      FROM surat_masuk sm
      WHERE sm.status_surat_id <> 5
      GROUP BY sm.disposisi_state
    `);

    const [rowsMonthly] = await pool.query(`
      SELECT 
        DATE_FORMAT(sm.tanggal_terima, '%Y-%m') AS period,
        COUNT(*) AS total
      FROM surat_masuk sm
      WHERE sm.status_surat_id <> 5
      GROUP BY DATE_FORMAT(sm.tanggal_terima, '%Y-%m')
      ORDER BY period DESC
      LIMIT 12
    `);

    const [rowsTotal] = await pool.query(`
      SELECT COUNT(*) AS total
      FROM surat_masuk sm
      WHERE sm.status_surat_id <> 5
    `);

    res.json({
      success: true,
      data: {
        total: rowsTotal[0]?.total || 0,
        byState: rowsState,
        byMonth: rowsMonthly,
      },
    });
  } catch (err) {
    console.error("ERROR GET /api/surat-masuk/stats:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// Di paling atas file (kalau belum ada)
router.get("/export", authenticate, async (req, res) => {
  try {
    const { state, q } = req.query;

    let where = "WHERE sm.status_surat_id <> 5";
    const params = [];

    if (state && state !== "all") {
      where += " AND sm.disposisi_state = ?";
      params.push(state);
    }

    if (q && q.trim() !== "") {
      where +=
        " AND (sm.nomor_surat LIKE ? OR sm.asal_surat LIKE ? OR sm.perihal LIKE ?)";
      const like = `%${q}%`;
      params.push(like, like, like);
    }

    const [rows] = await pool.query(
      `
      SELECT 
        sm.id,
        sm.nomor_agenda,
        sm.tanggal_terima,
        sm.nomor_surat,
        sm.asal_surat,
        sm.perihal,
        sm.disposisi_state,
        u.name AS unit_name
      FROM surat_masuk sm
      LEFT JOIN units u ON u.id = sm.unit_tujuan_id
      ${where}
      ORDER BY sm.tanggal_terima DESC, sm.id DESC
    `,
      params
    );

    // Mapping status ke label Indonesia
    const statusMap = {
      not_disposed: "Belum Didisposisi",
      in_disposition: "Dalam Proses",
      completed: "Selesai",
    };

    // Bentuk data yang sudah rapi untuk export
    const formatted = rows.map((row, index) => ({
      no: index + 1,
      nomor_agenda: row.nomor_agenda || "",
      tanggal_terima: row.tanggal_terima
        ? dayjs(row.tanggal_terima).format("DD-MM-YYYY")
        : "",
      nomor_surat: row.nomor_surat || "",
      asal_surat: row.asal_surat || "",
      perihal: row.perihal || "",
      status_disposisi: statusMap[row.disposisi_state] || "Tidak Diketahui",
      unit_tujuan: row.unit_name || "",
    }));

    res.json({
      success: true,
      data: formatted,
    });
  } catch (err) {
    console.error("ERROR GET /api/surat-masuk/export:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// ===========================
// GET LIST (Register)
// ===========================
router.get("/", authenticate, async (req, res) => {
  try {
    const { state, q, page = 1, limit = 10 } = req.query;

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.max(parseInt(limit, 10) || 10, 1);
    const offset = (pageNum - 1) * limitNum;

    let where = "WHERE sm.status_surat_id <> 5";
    const params = [];
    const countParams = [];

    if (state && state !== "all") {
      where += " AND sm.disposisi_state = ?";
      params.push(state);
      countParams.push(state);
    }

    if (q && q.trim() !== "") {
      where +=
        " AND (sm.nomor_surat LIKE ? OR sm.asal_surat LIKE ? OR sm.perihal LIKE ?)";
      const like = `%${q}%`;
      params.push(like, like, like);
      countParams.push(like, like, like);
    }

    const [countRows] = await pool.query(
      `
      SELECT COUNT(*) AS total
      FROM surat_masuk sm
      ${where}
    `,
      countParams
    );

    const total = countRows[0]?.total || 0;
    const lastPage = Math.max(Math.ceil(total / limitNum), 1);

    const [rows] = await pool.query(
      `
      SELECT sm.*, 
        js.name AS jenis_name,
        ms.name AS media_name,
        ss.name AS sifat_name,
        sc.title AS klasifikasi_name,
        u.name AS unit_name,
        st.name AS status_name
      FROM surat_masuk sm
      LEFT JOIN jenis_surat js ON js.id = sm.jenis_surat_id
      LEFT JOIN media_surat ms ON ms.id = sm.media_surat_id
      LEFT JOIN sifat_surat ss ON ss.id = sm.sifat_surat_id
      LEFT JOIN surat_classifications sc ON sc.id = sm.klasifikasi_id
      LEFT JOIN units u ON u.id = sm.unit_tujuan_id
      LEFT JOIN status_surat st ON st.id = sm.status_surat_id
      ${where}
      ORDER BY sm.tanggal_terima DESC, sm.id DESC
      LIMIT ? OFFSET ?
    `,
      [...params, limitNum, offset]
    );

    res.json({
      success: true,
      data: rows,
      meta: {
        total,
        page: pageNum,
        limit: limitNum,
        lastPage,
      },
    });
  } catch (err) {
    console.error("ERROR GET /api/surat-masuk:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});


// ===========================
// GET QUEUE (Belum / Proses / Selesai)
// GET /api/surat-masuk/queue?state=not_disposed|in_disposition|completed&search=...
// ===========================
router.get("/queue", authenticate, async (req, res) => {
  try {
    const state = toNull(req.query.state) || "not_disposed";
    const search = toNull(req.query.search);

    const allowedStates = ["not_disposed", "in_disposition", "completed"];
    if (!allowedStates.includes(state)) {
      return res.status(400).json({ success: false, message: "state tidak valid" });
    }

    const unitId = toIntOrNull(req.user?.unit_id);
    const admin = isAdminRole(req.user);
    const kepalaBadan = req.user?.role === "kepala-badan" || req.user?.role_slug === "kepala-badan";

    const params = [];
    let where = `
      WHERE sm.status_surat_id <> 5
    `;

    // search filter
    if (search) {
      where += ` AND (sm.nomor_surat LIKE ? OR sm.asal_surat LIKE ? OR sm.perihal LIKE ?) `;
      const like = `%${search}%`;
      params.push(like, like, like);
    }

    // RBAC by unit (only if not admin, not kepala-badan, and unitId present)
    const needsRestrictedUnit = !(admin || kepalaBadan) && unitId;
    if (needsRestrictedUnit) {
      where += `
        AND (
          sm.unit_tujuan_id = ?
          OR EXISTS (
            SELECT 1 FROM disposisi d
            WHERE d.surat_masuk_id = sm.id
              AND d.deleted_at IS NULL
              AND (d.dari_unit_id = ? OR d.kepada_unit_id = ?)
          )
        )
      `;
      params.push(unitId, unitId, unitId);
    }

    // state filter
    if (state === "not_disposed") {
      if (needsRestrictedUnit) {
        // restrict disposisi only for unit (not admin/kaban)
        where += `
          AND NOT EXISTS (
            SELECT 1 FROM disposisi d
            WHERE d.surat_masuk_id = sm.id
              AND d.kepada_unit_id = ?
              AND d.deleted_at IS NULL
          )
        `;
        params.push(unitId);
      } else {
        // admin/kaban: no unit filter, tampil semua yang belum punya disposisi
        where += `
          AND NOT EXISTS (
            SELECT 1 FROM disposisi d
            WHERE d.surat_masuk_id = sm.id
              AND d.deleted_at IS NULL
          )
        `;
      }
    } else if (state === "in_disposition") {
      where += `
        AND EXISTS (
          SELECT 1 FROM disposisi d
          WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL
        )
        AND EXISTS (
          SELECT 1 FROM disposisi d
          WHERE d.surat_masuk_id = sm.id
            AND d.deleted_at IS NULL
            AND COALESCE(d.status,'sent') NOT IN ('done','cancelled')
        )
      `;
    } else if (state === "completed") {
      where += `
        AND EXISTS (
          SELECT 1 FROM disposisi d
          WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL
        )
        AND NOT EXISTS (
          SELECT 1 FROM disposisi d
          WHERE d.surat_masuk_id = sm.id
            AND d.deleted_at IS NULL
            AND COALESCE(d.status,'sent') NOT IN ('done','cancelled')
        )
      `;
    }

    const sql = `
      SELECT
        sm.id,
        sm.tanggal_terima,
        sm.nomor_agenda,
        sm.nomor_surat,
        sm.asal_surat,
        sm.perihal,
        sm.file_surat,
        sm.unit_tujuan_id,

        u.name AS unit_name,

        -- unit terakhir dari disposisi (kalau surat belum punya unit_tujuan)
        ld.kepada_unit_id AS last_kepada_unit_id,
        u_last.name AS last_kepada_unit_name,

        -- unit yang ditampilkan (fallback)
        COALESCE(u.name, u_last.name) AS display_unit_name,

        (SELECT COUNT(*) FROM disposisi d WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL) AS disposisi_count,
        (SELECT COUNT(*) FROM disposisi d
          WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL
            AND COALESCE(d.status,'sent') NOT IN ('done','cancelled')
        ) AS disposisi_open_count,
        (SELECT MAX(d.created_at) FROM disposisi d WHERE d.surat_masuk_id = sm.id AND d.deleted_at IS NULL) AS last_disposisi_at

      FROM surat_masuk sm
      LEFT JOIN units u ON u.id = sm.unit_tujuan_id

      -- ambil disposisi terakhir (aktif) per surat
      LEFT JOIN (
        SELECT d1.surat_masuk_id, d1.kepada_unit_id
        FROM disposisi d1
        JOIN (
          SELECT surat_masuk_id, MAX(created_at) AS max_created
          FROM disposisi
          WHERE deleted_at IS NULL
          GROUP BY surat_masuk_id
        ) x ON x.surat_masuk_id = d1.surat_masuk_id AND x.max_created = d1.created_at
        WHERE d1.deleted_at IS NULL
      ) ld ON ld.surat_masuk_id = sm.id

      LEFT JOIN units u_last ON u_last.id = ld.kepada_unit_id

      ${where}
      ORDER BY sm.tanggal_terima DESC, sm.id DESC
    `;

    const [rows] = await pool.query(sql, params);
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET /api/surat-masuk/queue:", err);
    res.status(500).json({ success: false, message: "Gagal memuat queue surat masuk" });
  }
});

// ===========================
// GET NEXT AGENDA (AUTO NUMBER)
// ===========================
router.get("/next-agenda/now", authenticate, async (req, res) => {
  try {
    const year = new Date().getFullYear();

    const [rows] = await pool.query(
      `
      SELECT nomor_agenda
      FROM surat_masuk
      WHERE nomor_agenda LIKE ?
      ORDER BY id DESC
      LIMIT 1
      `,
      [`%/${year}`]
    );

    let next = 1;

    if (rows.length && rows[0].nomor_agenda) {
      const prefix = String(rows[0].nomor_agenda).split("/")[0];
      const current = parseInt(prefix, 10);
      if (!Number.isNaN(current)) next = current + 1;
    }

    const nomor_agenda = String(next).padStart(4, "0") + `/BKPSDM/${year}`;
    res.json({ success: true, nomor_agenda });
  } catch (err) {
    console.error("ERROR GET /api/surat-masuk/next-agenda/now:", err);
    res.status(500).json({ success: false, message: "Gagal membuat nomor agenda" });
  }
});

// ===========================
// DOWNLOAD & PREVIEW (MUST BE ABOVE "/:id")
// ===========================
router.get("/download/:filename", authenticateFileAccess, (req, res) => {
  const { filename } = req.params;

  if (!isSafeFilename(filename)) {
    return res.status(400).json({ success: false, message: "Nama file tidak valid" });
  }

  const filePath = path.join(uploadDir, filename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ success: false, message: "File tidak ditemukan" });
  }

  res.download(filePath);
});

router.get("/preview/:filename", authenticateFileAccess, (req, res) => {
  const { filename } = req.params;

  if (!isSafeFilename(filename)) {
    return res.status(400).json({ success: false, message: "Nama file tidak valid" });
  }

  const filePath = path.join(uploadDir, filename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ success: false, message: "File tidak ditemukan" });
  }

  res.sendFile(path.resolve(filePath));
});

// ===========================
// CREATE (WITH FILE UPLOAD)
// ===========================
router.post("/", authenticate, upload.single("file_surat"), async (req, res) => {
  const {
    nomor_agenda,
    tanggal_terima,
    tanggal_surat,
    nomor_surat,
    asal_surat,
    perihal,
    jenis_surat_id,
    media_surat_id,
    sifat_surat_id,
    klasifikasi_id,
    unit_tujuan_id,
    status_surat_id,
    lampiran,
  } = req.body;

  const fileName = req.file ? req.file.filename : null;

  try {
    const [result] = await pool.query(
      `INSERT INTO surat_masuk (
        nomor_agenda, tanggal_terima, tanggal_surat, nomor_surat, asal_surat, perihal,
        jenis_surat_id, media_surat_id, sifat_surat_id, klasifikasi_id, unit_tujuan_id,
        status_surat_id, lampiran, file_surat
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        toNull(nomor_agenda),
        toNull(tanggal_terima),
        toNull(tanggal_surat),
        toNull(nomor_surat),
        toNull(asal_surat),
        toNull(perihal),

        toIntOrNull(jenis_surat_id),
        toIntOrNull(media_surat_id),
        toIntOrNull(sifat_surat_id),
        toIntOrNull(klasifikasi_id),
        toIntOrNull(unit_tujuan_id),

        toIntOrNull(status_surat_id) ?? 1,
        toNull(lampiran),

        fileName,
      ]
    );

    res.json({
      success: true,
      message: "Berhasil menyimpan surat masuk",
      data: { id: result.insertId },
    });
  } catch (err) {
    console.error("ERROR CREATE:", err);
    res.status(500).json({ success: false, message: "Gagal menyimpan data" });
  }
});

// ===========================
// UPDATE (WITH FILE UPLOAD)
// ===========================
router.put("/:id", authenticate, upload.single("file_surat"), async (req, res) => {
  const id = toIntOrNull(req.params.id);
  if (!id) return res.status(400).json({ success: false, message: "ID tidak valid" });

  const {
    nomor_agenda,
    tanggal_terima,
    tanggal_surat,
    nomor_surat,
    asal_surat,
    perihal,
    jenis_surat_id,
    media_surat_id,
    sifat_surat_id,
    klasifikasi_id,
    unit_tujuan_id,
    status_surat_id,
    lampiran,
  } = req.body;

  const fileName = req.file ? req.file.filename : null;

  try {
    await pool.query(
      `UPDATE surat_masuk SET
        nomor_agenda = ?, tanggal_terima = ?, tanggal_surat = ?, nomor_surat = ?, asal_surat = ?, perihal = ?,
        jenis_surat_id = ?, media_surat_id = ?, sifat_surat_id = ?, klasifikasi_id = ?, unit_tujuan_id = ?,
        status_surat_id = ?, lampiran = ?, file_surat = COALESCE(?, file_surat)
      WHERE id = ?`,
      [
        toNull(nomor_agenda),
        toNull(tanggal_terima),
        toNull(tanggal_surat),
        toNull(nomor_surat),
        toNull(asal_surat),
        toNull(perihal),

        toIntOrNull(jenis_surat_id),
        toIntOrNull(media_surat_id),
        toIntOrNull(sifat_surat_id),
        toIntOrNull(klasifikasi_id),
        toIntOrNull(unit_tujuan_id),

        toIntOrNull(status_surat_id) ?? 1,
        toNull(lampiran),

        fileName,
        id,
      ]
    );

    res.json({ success: true, message: "Berhasil mengubah surat masuk" });
  } catch (err) {
    console.error("ERROR UPDATE:", err);
    res.status(500).json({ success: false, message: "Gagal mengubah data" });
  }
});

// ===========================
// DELETE (soft delete via status_surat_id=5)
// ===========================
router.delete("/:id", authenticate, async (req, res) => {
  const id = toIntOrNull(req.params.id);
  if (!id) return res.status(400).json({ success: false, message: "ID tidak valid" });

  try {
    await pool.query("UPDATE surat_masuk SET status_surat_id = 5 WHERE id = ?", [id]);
    res.json({ success: true, message: "Berhasil menghapus surat masuk" });
  } catch (err) {
    console.error("ERROR DELETE:", err);
    res.status(500).json({ success: false, message: "Gagal menghapus data" });
  }
});

// ===========================
// GET DETAIL (MUST BE LAST to avoid route conflicts)
// ===========================
router.get("/:id", authenticate, async (req, res) => {
  const id = toIntOrNull(req.params.id);
  if (!id) return res.status(400).json({ success: false, message: "ID tidak valid" });

  try {
    const [rows] = await pool.query(
      `
      SELECT sm.*, sc.code AS classification_code
      FROM surat_masuk sm
      LEFT JOIN surat_classifications sc ON sm.klasifikasi_id = sc.id
      WHERE sm.id = ?
      `,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: "Surat tidak ditemukan" });
    }

    res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error("ERROR GET /surat-masuk/:id:", err);
    res.status(500).json({ success: false, message: "Gagal mengambil detail surat" });
  }
});

export default router;