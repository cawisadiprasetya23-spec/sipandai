import express from "express";
import pool from "../db.js";
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

router.get("/", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT id, name, slug, level FROM roles ORDER BY level DESC"
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error("Roles error:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// =========================
// CREATE ROLE
// =========================
router.post("/", authenticate, async (req, res) => {
  const { name, slug, level, description } = req.body;

  try {
    const [result] = await pool.query(
      `INSERT INTO roles (name, slug, level, description)
       VALUES (?, ?, ?, ?)`,
      [name, slug, level, description]
    );

    res.json({ success: true, id: result.insertId });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// =========================
// UPDATE ROLE
// =========================
router.put("/:id", authenticate, async (req, res) => {
  const { name, slug, level, description } = req.body;
  const { id } = req.params;

  try {
    await pool.query(
      `UPDATE roles SET name = ?, slug = ?, level = ?, description = ? WHERE id = ?`,
      [name, slug, level, description, id]
    );

    const [updated] = await pool.query("SELECT * FROM roles WHERE id = ?", [id]);

    res.json({ success: true, data: updated[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// =========================
// DELETE ROLE
// =========================
router.delete("/:id", authenticate, async (req, res) => {
  const { id } = req.params;

  try {
    await pool.query("DELETE FROM roles WHERE id = ?", [id]);
    res.json({ success: true, message: "Role berhasil dihapus" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

export default router;
