//D:\surat-menyurat-monorepo\apps\api\routes\jenis_surat.js
import express from "express";
import pool from "../db.js";
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

// ===========================
// GET LIST
// ===========================
router.get("/", authenticate, async (req, res) => {
  const { search } = req.query;

  let sql = "SELECT * FROM jenis_surat WHERE 1=1";
  const params = [];

  if (search) {
    sql += " AND (code LIKE ? OR name LIKE ? OR description LIKE ?)";
    const like = `%${search}%`;
    params.push(like, like, like);
  }

  sql += " ORDER BY sort_order ASC, name ASC";

  try {
    const [rows] = await pool.query(sql, params);
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET /api/jenis-surat:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// ===========================
// GET DETAIL
// ===========================
router.get("/:id", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM jenis_surat WHERE id = ?",
      [req.params.id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Data tidak ditemukan" });
    }

    res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error("ERROR GET DETAIL:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// ===========================
// CREATE
// ===========================
router.post("/", authenticate, async (req, res) => {
  const { code, name, description, sort_order, is_active } = req.body;

  if (!code || !name) {
    return res.status(400).json({ success: false, message: "Kode dan nama wajib diisi" });
  }

  try {
    const [exists] = await pool.query(
      "SELECT id FROM jenis_surat WHERE code = ?",
      [code]
    );

    if (exists.length) {
      return res.status(400).json({ success: false, message: "Kode sudah digunakan" });
    }

    const [result] = await pool.query(
      `INSERT INTO jenis_surat (code, name, description, sort_order, is_active)
       VALUES (?, ?, ?, ?, ?)`,
      [
        code,
        name,
        description || null,
        sort_order || 0,
        is_active !== undefined ? !!is_active : true,
      ]
    );

    res.json({ success: true, data: { id: result.insertId } });
  } catch (err) {
    console.error("ERROR CREATE:", err);
    res.status(500).json({ success: false, message: "Gagal menyimpan data" });
  }
});

// ===========================
// UPDATE
// ===========================
router.put("/:id", authenticate, async (req, res) => {
  const { code, name, description, sort_order, is_active } = req.body;

  if (!code || !name) {
    return res.status(400).json({ success: false, message: "Kode dan nama wajib diisi" });
  }

  try {
    const [exists] = await pool.query(
      "SELECT id FROM jenis_surat WHERE code = ? AND id <> ?",
      [code, req.params.id]
    );

    if (exists.length) {
      return res.status(400).json({ success: false, message: "Kode sudah digunakan oleh data lain" });
    }

    await pool.query(
      `UPDATE jenis_surat
       SET code = ?, name = ?, description = ?, sort_order = ?, is_active = ?
       WHERE id = ?`,
      [
        code,
        name,
        description || null,
        sort_order || 0,
        is_active !== undefined ? !!is_active : true,
        req.params.id,
      ]
    );

    res.json({ success: true });
  } catch (err) {
    console.error("ERROR UPDATE:", err);
    res.status(500).json({ success: false, message: "Gagal mengubah data" });
  }
});

// ===========================
// DELETE (soft delete)
// ===========================
router.delete("/:id", authenticate, async (req, res) => {
  try {
    await pool.query(
      "UPDATE jenis_surat SET is_active = 0 WHERE id = ?",
      [req.params.id]
    );
    res.json({ success: true });
  } catch (err) {
    console.error("ERROR DELETE:", err);
    res.status(500).json({ success: false, message: "Gagal menghapus data" });
  }
});

export default router;
