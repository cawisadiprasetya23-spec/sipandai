//D:\surat-menyurat-monorepo\apps\api\routes\surat_keluar.js
import express from "express";
import pool from "../db.js";
import { authenticate } from "../middleware/auth.js";
import multer from "multer";
import path from "path";
import { upload } from "../utils/upload.js";
import { requireUnitForRole } from "../middleware/checkUnit.js";

const router = express.Router();

// GET /api/surat-keluar - fetch list surat keluar dengan filter
router.get("/", authenticate, requireUnitForRole, async (req, res) => {
  const status = req.query.status; // e.g. "draft", "nomor_requested", "numbered"
  const user = req.user;

  let sql = `
    SELECT 
      sk.*,
      js.name AS jenis_name,
      ms.name AS media_name,
      ss.name AS sifat_name,
      sc.title AS klasifikasi_name,
      sc.code AS classification_code
    FROM surat_keluar sk
    LEFT JOIN jenis_surat js ON js.id = sk.jenis_surat_id
    LEFT JOIN media_surat ms ON ms.id = sk.media_surat_id
    LEFT JOIN sifat_surat ss ON ss.id = sk.sifat_surat_id
    LEFT JOIN surat_classifications sc ON sc.id = sk.klasifikasi_id
    WHERE 1=1
  `;
  const params = [];

  // Filter status jika ada
  if (status) {
    sql += " AND sk.status = ? ";
    params.push(status);
  }

  // Filter unit untuk desentralisasi (non-admin hanya lihat unit sendiri)
  const isAdmin = ['superadmin', 'admin'].includes(user?.role_slug);
  if (!isAdmin && user?.unit_id) {
    sql += " AND sk.created_by_unit_id = ? ";
    params.push(user.unit_id);
  }

  sql += " ORDER BY sk.id DESC ";

  try {
    const [rows] = await pool.query(sql, params);
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET /api/surat-keluar:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// POST /api/surat-keluar - create surat keluar (draft) with file upload
router.post("/", authenticate, requireUnitForRole, upload.single('file_konsep_scan'), async (req, res) => {
  const {
    perihal,
    tujuan,
    isi,
    klasifikasi_id,
    jenis_surat_id,
    media_surat_id,
    sifat_surat_id,
    created_by_user_id,
    created_by_unit_id,
  } = req.body; // Sekarang req.body tersedia setelah multer

  if (!perihal || !tujuan || !klasifikasi_id) {
    return res.status(400).json({ success: false, message: "Perihal, tujuan, klasifikasi wajib" });
  }

  const user = req.user;
  const file_konsep_scan = req.file ? req.file.filename : null;

  try {
    const [result] = await pool.query(
      `INSERT INTO surat_keluar (
        perihal, tujuan, isi, klasifikasi_id, jenis_surat_id, media_surat_id, sifat_surat_id,
        file_konsep_scan, created_by_user_id, created_by_unit_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft')`,
      [
        perihal,
        tujuan,
        isi || null,
        klasifikasi_id,
        jenis_surat_id || null,
        media_surat_id || null,
        sifat_surat_id || null,
        file_konsep_scan,
        created_by_user_id || user.id,
        created_by_unit_id || user.unit_id,
      ]
    );

    // Log
    await pool.query(
      `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note) VALUES (?, 'create', ?, ?)`,
      [result.insertId, user.id, 'Draft created']
    );

    res.json({ success: true, message: "Surat keluar created", id: result.insertId });
  } catch (err) {
    console.error("ERROR POST /api/surat-keluar:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// Tambahkan endpoint untuk assign number
// POST /api/surat-keluar/:id/assign-number
router.post("/:id/assign-number", authenticate, async (req, res) => {
  const id = parseInt(req.params.id);
  if (!id) {
    return res.status(400).json({ success: false, message: "ID invalid" });
  }

  // Hanya admin BKPSDM yang boleh assign nomor
  const allowedRoles = ["admin", "superadmin"];
  if (!allowedRoles.includes(req.user.role_slug)) {
    return res.status(403).json({
      success: false,
      message: "Anda tidak memiliki akses untuk memberi nomor surat",
    });
  }

  const tahun = req.body.tahun || new Date().getFullYear();
  const conn = await pool.getConnection();

  try {
    await conn.beginTransaction();

    // Lock surat
    const [rows] = await conn.query(
      `SELECT id, status, klasifikasi_id 
       FROM surat_keluar 
       WHERE id = ? 
       FOR UPDATE`,
      [id]
    );

    if (!rows.length) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: "Surat tidak ditemukan" });
    }

    const surat = rows[0];

    // Validasi status
    if (surat.status !== "nomor_requested") {
      await conn.rollback();
      return res.status(400).json({
        success: false,
        message: `Surat dengan status '${surat.status}' tidak bisa diberi nomor`,
      });
    }

    // Ambil klasifikasi
    const [classRows] = await conn.query(
      `SELECT code, is_active 
       FROM surat_classifications 
       WHERE id = ?`,
      [surat.klasifikasi_id]
    );

    if (!classRows.length) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: "Klasifikasi tidak ditemukan" });
    }

    if (classRows[0].is_active === 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: "Klasifikasi tidak aktif" });
    }

    const classificationCode = classRows[0].code;

    // Lock sequence tahun
    await conn.query(
      `INSERT INTO surat_keluar_number_sequences (tahun, last_number)
       VALUES (?, 0)
       ON DUPLICATE KEY UPDATE last_number = last_number`,
      [tahun]
    );

    const [seqRows] = await conn.query(
      `SELECT last_number 
       FROM surat_keluar_number_sequences 
       WHERE tahun = ? 
       FOR UPDATE`,
      [tahun]
    );

    const last = seqRows[0].last_number || 0;
    const nextNumber = last + 1;

    // Update sequence
    await conn.query(
      `UPDATE surat_keluar_number_sequences 
       SET last_number = ? 
       WHERE tahun = ?`,
      [nextNumber, tahun]
    );

    // Format nomor surat final
    const urut = String(nextNumber).padStart(4, "0");
    const nomorSurat = `${classificationCode}/${urut}/BKPSDM/${tahun}`;

    // Update surat
    await conn.query(
      `UPDATE surat_keluar 
       SET nomor_urut = ?, tahun = ?, nomor_surat = ?, 
           status = 'numbered', updated_at = NOW()
       WHERE id = ?`,
      [nextNumber, tahun, nomorSurat, id]
    );

    await conn.commit();

    // Logging
    await pool.query(
      `INSERT INTO surat_keluar_logs 
       (surat_keluar_id, action, by_user_id, note)
       VALUES (?, 'assign_number', ?, ?)`,
      [id, req.user.id, `Nomor: ${nomorSurat}`]
    );

    return res.json({
      success: true,
      message: "Nomor berhasil diberikan",
      data: { nomor_surat: nomorSurat },
    });
  } catch (err) {
    await conn.rollback();
    console.error("ERROR assign-number:", err);
    return res.status(500).json({
      success: false,
      message: "Gagal assign nomor",
    });
  } finally {
    conn.release();
  }
});

// Tambahkan endpoint untuk submit nomor requested
router.post("/:id/submit-nomor-request", authenticate, requireUnitForRole, async (req, res) => {
  const id = parseInt(req.params.id);
  if (!id) return res.status(400).json({ success: false, message: "ID invalid" });

  try {
    await pool.query(
      `UPDATE surat_keluar SET status = 'nomor_requested', updated_at = NOW() WHERE id = ? AND status = 'draft'`,
      [id]
    );

    // Log
    await pool.query(
      `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note) VALUES (?, 'submit_nomor_request', ?, ?)`,
      [id, req.user.id, 'Submitted for numbering']
    );

    res.json({ success: true, message: "Submitted for numbering" });
  } catch (err) {
    console.error("ERROR submit-nomor-request:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

router.get("/masters", authenticate, async (req, res) => {
  try {
    const [jenis] = await pool.query("SELECT id, name FROM jenis_surat ORDER BY name");
    const [media] = await pool.query("SELECT id, name FROM media_surat ORDER BY name");
    const [sifat] = await pool.query("SELECT id, name FROM sifat_surat ORDER BY name");
    res.json({ success: true, data: { jenis, media, sifat } });
  } catch (err) {
    console.error("ERROR GET masters:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

router.get("/classifications", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT id, code, title, parent_code, level FROM surat_classifications ORDER BY level, code");
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET classifications:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// PUT /api/surat-keluar/:id - update draft atau nomor_requested
router.put("/:id", authenticate, requireUnitForRole, upload.single("file_konsep_scan"), async (req, res) => {
  const id = parseInt(req.params.id);
  if (!id) {
    return res.status(400).json({ success: false, message: "ID tidak valid" });
  }

  const {
    perihal,
    tujuan,
    klasifikasi_id,
    jenis_surat_id,
    media_surat_id,
    sifat_surat_id,
  } = req.body;

  if (!perihal || !tujuan || !klasifikasi_id) {
    return res.status(400).json({
      success: false,
      message: "Perihal, tujuan, dan klasifikasi wajib diisi",
    });
  }

  try {
    // Ambil data surat
    const [rows] = await pool.query(
      `SELECT id, status, file_konsep_scan 
       FROM surat_keluar 
       WHERE id = ?`,
      [id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Surat tidak ditemukan" });
    }

    const surat = rows[0];

    // Status yang boleh di-edit
    const allowed = ["draft", "nomor_requested"];

    if (!allowed.includes(surat.status)) {
      return res.status(400).json({
        success: false,
        message: `Surat dengan status '${surat.status}' tidak bisa diedit`,
      });
    }

    // Jika upload file baru → pakai file baru
    const file_konsep_scan = req.file ? req.file.filename : surat.file_konsep_scan;

    // Update data
    await pool.query(
      `UPDATE surat_keluar
       SET perihal = ?, tujuan = ?, klasifikasi_id = ?, 
           jenis_surat_id = ?, media_surat_id = ?, sifat_surat_id = ?, 
           file_konsep_scan = ?, updated_at = NOW()
       WHERE id = ?`,
      [
        perihal,
        tujuan,
        klasifikasi_id,
        jenis_surat_id || null,
        media_surat_id || null,
        sifat_surat_id || null,
        file_konsep_scan,
        id,
      ]
    );

    // Logging
    await pool.query(
      `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note)
       VALUES (?, 'update_draft', ?, ?)`,
      [id, req.user.id, "Surat diperbarui oleh user"]
    );

    return res.json({
      success: true,
      message: "Surat berhasil diperbarui",
    });
  } catch (err) {
    console.error("ERROR PUT /api/surat-keluar/:id:", err);
    return res.status(500).json({
      success: false,
      message: "Terjadi kesalahan pada server",
    });
  }
});

// POST /api/surat-keluar/:id/upload-final
router.post("/:id/upload-final",authenticate, requireUnitForRole, upload.fields([
    { name: "file_final_pdf", maxCount: 1 },
    { name: "file_lampiran", maxCount: 1 },
  ]),
  async (req, res) => {
    const id = parseInt(req.params.id);
    if (!id) {
      return res.status(400).json({ success: false, message: "ID tidak valid" });
    }

    const userId = req.user.id;

    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();

      const [rows] = await conn.query(
        `SELECT id, status, file_final_pdf, file_lampiran 
         FROM surat_keluar 
         WHERE id = ? FOR UPDATE`,
        [id]
      );

      if (!rows.length) {
        await conn.rollback();
        return res.status(404).json({ success: false, message: "Surat tidak ditemukan" });
      }

      const surat = rows[0];

      if (!["nomor_assigned", "upload_final"].includes(surat.status)) {
        await conn.rollback();
        return res.status(400).json({
          success: false,
          message: `Surat dengan status '${surat.status}' tidak bisa upload final`,
        });
      }

      const fileFinal = req.files?.file_final_pdf?.[0]?.filename || surat.file_final_pdf;
      const fileLampiran = req.files?.file_lampiran?.[0]?.filename || surat.file_lampiran;

      if (!fileFinal) {
        await conn.rollback();
        return res.status(400).json({
          success: false,
          message: "File final PDF wajib diupload",
        });
      }

      // Hitung SHA256 dari file final
      const path = require("path");
      const fs = require("fs");
      const crypto = require("crypto");

      const filePath = path.join(__dirname, "..", "..", "uploads", "surat_keluar", fileFinal);
      const buffer = fs.readFileSync(filePath);
      const sha256 = crypto.createHash("sha256").update(buffer).digest("hex");

      // Simpan ke database
      await conn.query(
        `UPDATE surat_keluar
         SET file_final_pdf = ?, file_lampiran = ?, pdf_final_sha256 = ?, status = 'waiting_acc', updated_at = NOW()
         WHERE id = ?`,
        [fileFinal, fileLampiran, sha256, id]
      );

      await conn.query(
        `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note)
         VALUES (?, 'upload_final', ?, ?)`,
        [id, userId, "Upload surat final"]
      );

      await conn.commit();
      return res.json({
        success: true,
        message: "Surat final berhasil diupload dan dikirim ke ACC Kepala Badan",
      });
    } catch (err) {
      await conn.rollback();
      console.error("ERROR upload-final:", err);
      return res.status(500).json({
        success: false,
        message: "Terjadi kesalahan pada server",
      });
    } finally {
      conn.release();
    }
  }
);


// POST /api/surat-keluar/:id/acc
router.post("/:id/acc", authenticate, requireUnitForRole, async (req, res) => {
  const id = parseInt(req.params.id);
  if (!id) {
    return res.status(400).json({ success: false, message: "ID tidak valid" });
  }

  const allowedRoles = ["superadmin", "admin", "kepala_badan"];
  if (!allowedRoles.includes(req.user.role_slug)) {
    return res.status(403).json({
      success: false,
      message: "Anda tidak memiliki akses untuk ACC surat",
    });
  }

  const { status_catatan } = req.body || {};

  try {
    const [rows] = await pool.query(
      `SELECT id, status, file_final_pdf 
       FROM surat_keluar 
       WHERE id = ?`,
      [id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Surat tidak ditemukan" });
    }

    const surat = rows[0];

    if (surat.status !== "upload_final") {
      return res.status(400).json({
        success: false,
        message: `Surat dengan status '${surat.status}' tidak bisa di-ACC`,
      });
    }

    if (!surat.file_final_pdf) {
      return res.status(400).json({
        success: false,
        message: "File final belum diupload",
      });
    }

    await pool.query(
      `UPDATE surat_keluar
       SET status = 'acc',
           acc_by_user_id = ?,
           acc_at = NOW(),
           status_catatan = ?,
           updated_at = NOW()
       WHERE id = ?`,
      [req.user.id, status_catatan || null, id]
    );

    await pool.query(
      `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note)
       VALUES (?, 'acc', ?, ?)`,
      [id, req.user.id, "ACC Kepala Badan"]
    );

    return res.json({
      success: true,
      message: "Surat berhasil di-ACC",
    });
  } catch (err) {
    console.error("ERROR ACC:", err);
    return res.status(500).json({
      success: false,
      message: "Terjadi kesalahan pada server",
    });
  }
});

// POST /api/surat-keluar/:id/tte
router.post("/:id/tte",authenticate, requireUnitForRole, upload.single("file_tte_pdf"),async (req, res) => {
    const id = parseInt(req.params.id);
    if (!id) {
      return res.status(400).json({ success: false, message: "ID tidak valid" });
    }

    const allowedRoles = ["superadmin", "admin", "kepala_badan"];
    if (!allowedRoles.includes(req.user.role_slug)) {
      return res.status(403).json({
        success: false,
        message: "Anda tidak memiliki akses untuk proses TTE",
      });
    }

    const { pdf_final_sha256 } = req.body || {};

    try {
      const [rows] = await pool.query(
        `SELECT id, status, file_final_pdf 
         FROM surat_keluar 
         WHERE id = ?`,
        [id]
      );

      if (!rows.length) {
        return res.status(404).json({ success: false, message: "Surat tidak ditemukan" });
      }

      const surat = rows[0];

      if (surat.status !== "acc") {
        return res.status(400).json({
          success: false,
          message: `Surat dengan status '${surat.status}' tidak bisa diproses TTE`,
        });
      }

      if (!surat.file_final_pdf) {
        return res.status(400).json({
          success: false,
          message: "File final belum tersedia",
        });
      }

      const fileTTE = req.file ? req.file.filename : null;

      if (!fileTTE) {
        return res.status(400).json({
          success: false,
          message: "File TTE PDF wajib diupload",
        });
      }

      await pool.query(
        `UPDATE surat_keluar
         SET status = 'tte_done',
             file_tte_pdf = ?,
             pdf_final_sha256 = ?,
             tte_by_user_id = ?,
             tte_at = NOW(),
             updated_at = NOW()
         WHERE id = ?`,
        [fileTTE, pdf_final_sha256 || null, req.user.id, id]
      );

      await pool.query(
        `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note)
         VALUES (?, 'tte_done', ?, ?)`,
        [id, req.user.id, "TTE selesai"]
      );

      return res.json({
        success: true,
        message: "Proses TTE selesai",
      });
    } catch (err) {
      console.error("ERROR TTE:", err);
      return res.status(500).json({
        success: false,
        message: "Terjadi kesalahan pada server",
      });
    }
  }
);

// POST /api/surat-keluar/:id/arsip
router.post("/:id/arsip", authenticate, requireUnitForRole, async (req, res) => {
  const id = parseInt(req.params.id);
  if (!id) {
    return res.status(400).json({ success: false, message: "ID tidak valid" });
  }

  const allowedRoles = ["superadmin", "admin"];
  if (!allowedRoles.includes(req.user.role_slug)) {
    return res.status(403).json({
      success: false,
      message: "Anda tidak memiliki akses untuk mengarsipkan surat",
    });
  }

  try {
    const [rows] = await pool.query(
      `SELECT id, status, file_tte_pdf 
       FROM surat_keluar 
       WHERE id = ?`,
      [id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Surat tidak ditemukan" });
    }

    const surat = rows[0];

    if (surat.status !== "tte_done") {
      return res.status(400).json({
        success: false,
        message: `Surat dengan status '${surat.status}' belum bisa diarsipkan`,
      });
    }

    if (!surat.file_tte_pdf) {
      return res.status(400).json({
        success: false,
        message: "File TTE belum tersedia",
      });
    }

    await pool.query(
      `UPDATE surat_keluar
       SET status = 'arsip',
           updated_at = NOW()
       WHERE id = ?`,
      [id]
    );

    await pool.query(
      `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note)
       VALUES (?, 'arsip', ?, ?)`,
      [id, req.user.id, "Surat diarsipkan"]
    );

    return res.json({
      success: true,
      message: "Surat berhasil diarsipkan",
    });
  } catch (err) {
    console.error("ERROR arsip:", err);
    return res.status(500).json({
      success: false,
      message: "Terjadi kesalahan pada server",
    });
  }
});

router.get("/histori-upload-final", authenticate, requireUnitForRole, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT 
        sk.id,
        sk.perihal,
        sk.nomor_surat,
        sk.file_final_pdf,
        sk.file_lampiran,
        l.created_at AS uploaded_at,
        u.username AS uploaded_by
      FROM surat_keluar sk
      INNER JOIN surat_keluar_logs l 
        ON l.surat_keluar_id = sk.id 
       AND l.action = 'upload_final'
      LEFT JOIN users u 
        ON u.id = l.by_user_id
      WHERE sk.status = 'upload_final'
      ORDER BY l.created_at DESC`
    );

    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET histori-upload-final:", err);
    return res.status(500).json({
      success: false,
      message: "Gagal memuat histori upload final",
    });
  }
});

// GET /surat-keluar/acc-kaban
router.get("/acc-kaban", authenticate, requireUnitForRole, async (req, res) => {
  console.log("ACC KABAN HIT");
  try {
    const [rows] = await pool.query(
      `SELECT 
        id,
        perihal,
        nomor_surat,
        file_final_pdf,
        status
      FROM surat_keluar
      WHERE status = 'waiting_acc'
      ORDER BY updated_at DESC`
    );

    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET acc-kaban:", err);
    return res.status(500).json({ success: false, message: "Gagal memuat ACC" });
  }
});


// POST /surat-keluar/acc-kaban/:id/acc
router.post("/acc-kaban/:id/acc", authenticate, requireUnitForRole, async (req, res) => {
  const suratId = req.params.id;
  const userId = req.user.id;

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [check] = await conn.query(
      `SELECT status FROM surat_keluar WHERE id = ? FOR UPDATE`,
      [suratId]
    );
    if (!check.length || check[0].status !== "waiting_acc") {
      await conn.rollback();
      return res.status(400).json({ success: false, message: "Status surat tidak valid untuk ACC" });
    }

    await conn.query(
      `UPDATE surat_keluar
       SET status = 'acc',
           acc_by_user_id = ?,
           acc_at = NOW()
       WHERE id = ?`,
      [userId, suratId]
    );

    await conn.query(
      `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note)
       VALUES (?, 'acc', ?, 'ACC Kepala Badan')`,
      [suratId, userId]
    );

    await conn.commit();
    return res.json({ success: true, message: "Surat berhasil di-ACC" });
  } catch (err) {
    await conn.rollback();
    console.error("ERROR POST acc-kaban acc:", err);
    return res.status(500).json({ success: false, message: "Gagal ACC surat" });
  } finally {
    conn.release();
  }
});

// POST /surat-keluar/acc-kaban/:id/reject
router.post("/acc-kaban/:id/reject", authenticate, requireUnitForRole, async (req, res) => {
  const suratId = req.params.id;
  const userId = req.user.id;
  const { note } = req.body;

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [check] = await conn.query(
      `SELECT status FROM surat_keluar WHERE id = ? FOR UPDATE`,
      [suratId]
    );
    if (!check.length || check[0].status !== "waiting_acc") {
      await conn.rollback();
      return res.status(400).json({ success: false, message: "Status surat tidak valid untuk penolakan" });
    }

    await conn.query(
      `UPDATE surat_keluar
       SET status = 'draft'
       WHERE id = ?`,
      [suratId]
    );

    await conn.query(
      `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note)
       VALUES (?, 'acc_reject', ?, ?)`,
      [suratId, userId, note || "ACC ditolak"]
    );

    await conn.commit();
    return res.json({ success: true, message: "Surat dikembalikan ke draft" });
  } catch (err) {
    await conn.rollback();
    console.error("ERROR POST acc-kaban reject:", err);
    return res.status(500).json({ success: false, message: "Gagal menolak surat" });
  } finally {
    conn.release();
  }
});

// GET /surat-keluar/arsip
router.get("/arsip", authenticate, requireUnitForRole, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT 
        sk.id,
        sk.perihal,
        sk.nomor_surat,
        sk.file_tte_pdf,
        sk.tte_at,
        sk.status
      FROM surat_keluar sk
      WHERE sk.status = 'arsip'
      ORDER BY sk.tte_at DESC`
    );

    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET arsip:", err);
    return res.status(500).json({ success: false, message: "Gagal memuat arsip surat keluar" });
  }
});

// POST /surat-keluar/arsip/:id
router.post("/arsip/:id", authenticate, requireUnitForRole, async (req, res) => {
  const suratId = req.params.id;
  const userId = req.user.id;

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [check] = await conn.query(
      `SELECT status FROM surat_keluar WHERE id = ? FOR UPDATE`,
      [suratId]
    );
    if (!check.length || check[0].status !== "tte_done") {
      await conn.rollback();
      return res.status(400).json({ success: false, message: "Status surat tidak valid untuk arsip" });
    }

    await conn.query(
      `UPDATE surat_keluar
       SET status = 'arsip'
       WHERE id = ?`,
      [suratId]
    );

    await conn.query(
      `INSERT INTO surat_keluar_logs (surat_keluar_id, action, by_user_id, note)
       VALUES (?, 'arsip', ?, 'Surat diarsipkan')`,
      [suratId, userId]
    );

    await conn.commit();
    return res.json({ success: true, message: "Surat berhasil diarsipkan" });
  } catch (err) {
    await conn.rollback();
    console.error("ERROR POST arsip:", err);
    return res.status(500).json({ success: false, message: "Gagal mengarsipkan surat" });
  } finally {
    conn.release();
  }
});

// POST /surat-keluar/verifikasi-hash
router.post("/verifikasi-hash", async (req, res) => {
  const { hash } = req.body;

  if (!hash) {
    return res.status(400).json({ success: false, message: "Hash wajib diisi" });
  }

  try {
    const [rows] = await pool.query(
      `SELECT 
        id,
        perihal,
        nomor_surat,
        status
      FROM surat_keluar
      WHERE pdf_final_sha256 = ?`,
      [hash]
    );

    if (!rows.length) {
      return res.json({ success: false, message: "Surat tidak ditemukan / tidak valid" });
    }

    return res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error("ERROR POST verifikasi-hash:", err);
    return res.status(500).json({ success: false, message: "Gagal memverifikasi hash" });
  }
});

// ===========================
// SIGNED (Surat Tertandatangani)
// ===========================
router.get("/signed", authenticate, requireUnitForRole, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT 
        sk.id,
        sk.perihal,
        sk.nomor_surat,
        sk.file_tte_pdf,
        sk.tte_done_at
      FROM surat_keluar sk
      WHERE sk.status = 'signed'
      ORDER BY sk.tte_done_at DESC`
    );

    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET signed:", err);
    return res.status(500).json({ success: false, message: "Gagal memuat surat tertandatangani" });
  }
});

//import { signPDF } from "../tte/signer.js";

export default router;