//D:\surat-menyurat-monorepo\apps\api\routes\disposisi_tindak_lanjut_upload.js
import express from "express";
import { authenticate } from "../middleware/auth.js";
import { uploadTindakLanjut } from "../middleware/uploadTindakLanjut.js";
import * as controller from "../controllers/disposisiTindakLanjutUpload.controller.js";

const router = express.Router();

// POST /api/disposisi/:disposisiId/tindak-lanjut/lampiran
router.post(
  "/:disposisiId/tindak-lanjut/lampiran",
  authenticate,
  uploadTindakLanjut.single("file"),
  controller.uploadLampiran
);

export default router;