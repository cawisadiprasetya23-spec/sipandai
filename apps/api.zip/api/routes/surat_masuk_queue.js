//D:\surat-menyurat-monorepo\apps\api\routes\surat_masuk_queue.js
import express from "express";
import { authenticate } from "../middleware/auth.js";
import * as controller from "../controllers/suratMasukQueue.controller.js";

const router = express.Router();

// /api/surat-masuk/queue?state=not_disposed|in_disposition|completed&search=...
router.get("/", authenticate, controller.listQueue);

export default router;