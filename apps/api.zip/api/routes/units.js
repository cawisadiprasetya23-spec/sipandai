import express from "express";
import pool from "../db.js";
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

// ===========================
// GET ALL UNITS
// ===========================
router.get("/", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT id, name, slug, type FROM units ORDER BY id ASC"
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET /api/units:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// ===========================
// CREATE UNIT
// ===========================
router.post("/", authenticate, async (req, res) => {
  const { name, slug, type } = req.body;

  if (!name || !slug || !type) {
    return res.status(400).json({ success: false, message: "Data tidak lengkap" });
  }

  try {
    await pool.query(
      "INSERT INTO units (name, slug, type) VALUES (?, ?, ?)",
      [name, slug, type]
    );
    res.json({ success: true, message: "Unit berhasil ditambahkan" });
  } catch (err) {
    console.error("ERROR POST /api/units:", err);
    res.status(500).json({ success: false, message: "Gagal menambahkan unit" });
  }
});

// ===========================
// UPDATE UNIT
// ===========================
router.put("/:id", authenticate, async (req, res) => {
  const { name, slug, type } = req.body;

  if (!name || !slug || !type) {
    return res.status(400).json({ success: false, message: "Data tidak lengkap" });
  }

  try {
    await pool.query(
      "UPDATE units SET name = ?, slug = ?, type = ? WHERE id = ?",
      [name, slug, type, req.params.id]
    );
    res.json({ success: true, message: "Unit berhasil diperbarui" });
  } catch (err) {
    console.error("ERROR PUT /api/units:", err);
    res.status(500).json({ success: false, message: "Gagal memperbarui unit" });
  }
});

// ===========================
// DELETE UNIT
// ===========================
router.delete("/:id", authenticate, async (req, res) => {
  try {
    await pool.query("DELETE FROM units WHERE id = ?", [req.params.id]);
    res.json({ success: true, message: "Unit berhasil dihapus" });
  } catch (err) {
    console.error("ERROR DELETE /api/units:", err);
    res.status(500).json({ success: false, message: "Gagal menghapus unit" });
  }
});

export default router;
