//D:\surat-menyurat-monorepo\apps\api\routes\surat_masuk_timeline.js
import express from "express";
import { authenticate } from "../middleware/auth.js";
import * as controller from "../controllers/suratMasukTimeline.controller.js";

const router = express.Router();

// GET /api/surat-masuk/:id/timeline
router.get("/:id", authenticate, controller.getTimeline);


export default router;