import express from "express";
import pool from "../db.js";
import { authenticate } from "../middleware/auth.js";
import { onlyRole } from "../middleware/roles.js";

const router = express.Router();

// =========================
// GET ALL PERMISSIONS
// =========================
router.get("/", authenticate, onlyRole("superadmin"), async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT id, name
      FROM permissions
      ORDER BY id ASC
    `);

    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// =========================
// CREATE PERMISSION
// =========================
router.post("/", authenticate, onlyRole("superadmin"), async (req, res) => {
  const { name } = req.body;

  if (!name)
    return res.status(400).json({ success: false, message: "Nama permission wajib diisi" });

  try {
    const [result] = await pool.query(
      `INSERT INTO permissions (name) VALUES (?)`,
      [name]
    );

    res.json({ success: true, id: result.insertId });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// =========================
// UPDATE PERMISSION
// =========================
router.put("/:id", authenticate, onlyRole("superadmin"), async (req, res) => {
  const { name } = req.body;
  const { id } = req.params;

  if (!name)
    return res.status(400).json({ success: false, message: "Nama permission wajib diisi" });

  try {
    await pool.query(
      `UPDATE permissions SET name = ? WHERE id = ?`,
      [name, id]
    );

    const [updated] = await pool.query("SELECT * FROM permissions WHERE id = ?", [id]);

    res.json({ success: true, data: updated[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// =========================
// DELETE PERMISSION
// =========================
router.delete("/:id", authenticate, onlyRole("superadmin"), async (req, res) => {
  const { id } = req.params;

  try {
    await pool.query("DELETE FROM permissions WHERE id = ?", [id]);
    res.json({ success: true, message: "Permission berhasil dihapus" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

export default router;
