//D:\surat-menyurat-monorepo\apps\api\routes\disposisi.js
import express from "express";
import { authenticate } from "../middleware/auth.js";
import * as controller from "../controllers/disposisi.controller.js";

const router = express.Router();

router.get("/", authenticate, controller.list);
router.get("/:id", authenticate, controller.detail);
router.post("/", authenticate, controller.create);
router.put("/:id", authenticate, controller.update);
router.delete("/:id", authenticate, controller.remove);

export default router;