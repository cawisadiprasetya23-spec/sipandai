import express from "express";
import { authenticate } from "../middleware/auth.js";
import { getDashboardSummary } from "../services/dashboard.service.js";

const router = express.Router();

router.get("/summary", authenticate, async (req, res) => {
  try {
    const data = await getDashboardSummary(req);
    return res.json({ success: true, data });
  } catch (e) {
    console.error("Dashboard summary error:", e);
    return res.status(e.status || 500).json({
      success: false,
      message: e.message || "Internal Server Error",
    });
  }
});

export default router;