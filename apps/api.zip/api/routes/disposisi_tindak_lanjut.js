//D:\surat-menyurat-monorepo\apps\api\routes\disposisi_tindak_lanjut.js
import express from "express";
import { authenticate } from "../middleware/auth.js";
import * as controller from "../controllers/disposisiTindakLanjut.controller.js";

const router = express.Router();

router.get("/:disposisiId/tindak-lanjut", authenticate, controller.get);
router.put("/:disposisiId/tindak-lanjut", authenticate, controller.upsert);
router.delete("/:disposisiId/tindak-lanjut", authenticate, controller.remove);

export default router;