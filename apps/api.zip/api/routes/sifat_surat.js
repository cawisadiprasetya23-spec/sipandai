import express from "express";
import db from "../db.js"; // sesuaikan path DB kamu
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

// GET list
router.get("/", async (req, res) => {
  const { search } = req.query;

  let sql = "SELECT * FROM sifat_surat WHERE 1=1";
  const params = [];

  if (search) {
    sql += " AND (code LIKE ? OR name LIKE ? OR description LIKE ?)";
    const like = `%${search}%`;
    params.push(like, like, like);
  }

  sql += " ORDER BY sort_order ASC, name ASC";

  try {
    const [rows] = await db.query(sql, params);
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal mengambil data" });
  }
});

// GET detail
router.get("/:id", async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT * FROM sifat_surat WHERE id = ?",
      [req.params.id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Data tidak ditemukan" });
    }

    res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal mengambil data" });
  }
});

// POST create
router.post("/", async (req, res) => {
  const { code, name, description, is_urgent, is_confidential, sort_order, is_active } = req.body;

  if (!code || !name) {
    return res.status(400).json({ success: false, message: "Kode dan nama wajib diisi" });
  }

  try {
    const [exists] = await db.query(
      "SELECT id FROM sifat_surat WHERE code = ?",
      [code]
    );

    if (exists.length) {
      return res.status(400).json({ success: false, message: "Kode sudah digunakan" });
    }

    const [result] = await db.query(
      `INSERT INTO sifat_surat 
       (code, name, description, is_urgent, is_confidential, sort_order, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        code,
        name,
        description || null,
        !!is_urgent,
        !!is_confidential,
        sort_order || 0,
        is_active !== undefined ? !!is_active : true,
      ]
    );

    res.json({ success: true, data: { id: result.insertId } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal menyimpan data" });
  }
});

// PUT update
router.put("/:id", async (req, res) => {
  const { code, name, description, is_urgent, is_confidential, sort_order, is_active } = req.body;

  if (!code || !name) {
    return res.status(400).json({ success: false, message: "Kode dan nama wajib diisi" });
  }

  try {
    const [exists] = await db.query(
      "SELECT id FROM sifat_surat WHERE code = ? AND id <> ?",
      [code, req.params.id]
    );

    if (exists.length) {
      return res.status(400).json({ success: false, message: "Kode sudah digunakan oleh data lain" });
    }

    await db.query(
      `UPDATE sifat_surat
       SET code = ?, name = ?, description = ?, 
           is_urgent = ?, is_confidential = ?, sort_order = ?, is_active = ?
       WHERE id = ?`,
      [
        code,
        name,
        description || null,
        !!is_urgent,
        !!is_confidential,
        sort_order || 0,
        is_active !== undefined ? !!is_active : true,
        req.params.id,
      ]
    );

    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal mengubah data" });
  }
});

// DELETE (soft delete)
router.delete("/:id", async (req, res) => {
  try {
    await db.query(
      "UPDATE sifat_surat SET is_active = 0 WHERE id = ?",
      [req.params.id]
    );
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Gagal menghapus data" });
  }
});

export default router;
