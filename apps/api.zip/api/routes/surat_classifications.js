import express from "express";
import pool from "../db.js";
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

// ===========================
// TREE (LEVEL 1–4) — REKURSIF
// ===========================
router.get("/tree", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT id, code, title, parent_code FROM surat_classifications ORDER BY code ASC"
    );

    const map = {};
    const tree = [];

    // Buat map
    rows.forEach(row => {
      map[row.code] = {
        id: row.id,
        code: row.code,
        title: row.title,
        parent_code: row.parent_code,
        children: []
      };
    });

    // Susun tree
    rows.forEach(row => {
      const node = map[row.code];
      if (row.parent_code && map[row.parent_code]) {
        map[row.parent_code].children.push(node);
      } else {
        tree.push(node);
      }
    });

    // Rekursif: susun anak-anak
    function attachChildren(node) {
      node.children.forEach(child => {
        child.children = map[child.code]?.children || [];
        attachChildren(child);
      });
    }

    tree.forEach(attachChildren);
    res.json({ success: true, data: tree });

  } catch (err) {
    console.error("ERROR TREE:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// ===========================
// GET ALL (NO LIMIT)
router.get("/all", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM surat_classifications ORDER BY code ASC"
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    console.error("ERROR GET /all:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

// ===========================
// CHECK CODE
router.get("/check-code", authenticate, async (req, res) => {
  const { code } = req.query;
  if (!code) return res.status(400).json({ success: false, message: "Kode kosong" });

  try {
    const [rows] = await pool.query(
      `SELECT COUNT(*) AS count FROM surat_classifications WHERE code = ?`,
      [code]
    );
    res.json({ success: true, exists: rows[0].count > 0 });
  } catch (err) {
    console.error("ERROR CHECK CODE:", err);
    res.status(500).json({ success: false, message: "Gagal cek kode" });
  }
});

// ===========================
// GET PAGINATED
router.get("/", authenticate, async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const search = req.query.search || "";
  const offset = (page - 1) * limit;

  try {
    const [rows] = await pool.query(
      `
      SELECT * FROM surat_classifications
      WHERE code LIKE ? OR title LIKE ? OR description LIKE ?
      ORDER BY code ASC
      LIMIT ? OFFSET ?
      `,
      [`%${search}%`, `%${search}%`, `%${search}%`, limit, offset]
    );

    const [[{ total }]] = await pool.query(
      `
      SELECT COUNT(*) AS total FROM surat_classifications
      WHERE code LIKE ? OR title LIKE ? OR description LIKE ?
      `,
      [`%${search}%`, `%${search}%`, `%${search}%`]
    );

    res.json({ success: true, data: rows, total, page, limit });
  } catch (err) {
    console.error("ERROR GET /:", err);
    res.status(500).json({ success: false, message: "Database error" });
  }
});

router.get("/:id", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `
      SELECT sm.*, sc.code AS classification_code
      FROM surat_masuk sm
      LEFT JOIN surat_classifications sc ON sm.klasifikasi_id = sc.id
      WHERE sm.id = ?
      `,
      [req.params.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: "Surat tidak ditemukan" });
    }

    res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error("ERROR GET /surat-masuk/:id:", err);
    res.status(500).json({ success: false, message: "Gagal mengambil detail surat" });
  }
});

// ===========================
// CREATE
router.post("/", authenticate, async (req, res) => {
  const { code, title, description, parent_code, level, is_active } = req.body;

  if (!code || !title || level === undefined) {
    return res.status(400).json({ success: false, message: "Data tidak lengkap" });
  }

  try {
    await pool.query(
      `INSERT INTO surat_classifications (code, title, description, parent_code, level, is_active)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [code, title, description ?? null, parent_code ?? null, level, is_active ?? true]
    );
    res.json({ success: true, message: "Klasifikasi surat berhasil ditambahkan" });
  } catch (err) {
    console.error("ERROR POST /:", err);
    res.status(500).json({ success: false, message: "Gagal menambahkan klasifikasi surat" });
  }
});

// ===========================
// UPDATE
router.put("/:id", authenticate, async (req, res) => {
  const { code, title, description, parent_code, level, is_active } = req.body;

  if (!code || !title || level === undefined) {
    return res.status(400).json({ success: false, message: "Data tidak lengkap" });
  }

  try {
    await pool.query(
      `UPDATE surat_classifications SET code = ?, title = ?, description = ?, parent_code = ?, level = ?, is_active = ?
       WHERE id = ?`,
      [code, title, description ?? null, parent_code ?? null, level, is_active ?? true, req.params.id]
    );
    res.json({ success: true, message: "Klasifikasi surat berhasil diperbarui" });
  } catch (err) {
    console.error("ERROR PUT /:", err);
    res.status(500).json({ success: false, message: "Gagal memperbarui klasifikasi surat" });
  }
});

// ===========================
// DELETE
router.delete("/:id", authenticate, async (req, res) => {
  try {
    await pool.query("DELETE FROM surat_classifications WHERE id = ?", [req.params.id]);
    res.json({ success: true, message: "Klasifikasi surat berhasil dihapus" });
  } catch (err) {
    console.error("ERROR DELETE /:", err);
    res.status(500).json({ success: false, message: "Gagal menghapus klasifikasi surat" });
  }
});

export default router;
