//D:\surat-menyurat-monorepo\apps\api\routes\disposisi_monitoring.js
import express from "express";
import { authenticate } from "../middleware/auth.js";
import * as controller from "../controllers/disposisiMonitoring.controller.js";

const router = express.Router();

router.get("/monitoring/surat/:suratMasukId", authenticate, controller.getBySurat);
router.patch("/:id/status", authenticate, controller.updateStatus);

export default router;