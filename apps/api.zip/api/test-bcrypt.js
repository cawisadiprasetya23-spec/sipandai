import bcrypt from "bcryptjs";

const hash = "$2b$10$uG8YpY70dNDO7xjoMnIKhO4rVqCkCmZJLdnOjFkWDXLI4YAlnXrhG";

bcrypt.compare("password123", hash).then(result => {
  console.log("COMPARE RESULT:", result);
});
