import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

const dbHost = process.env.DB_HOST || process.env.MYSQL_HOST || "localhost";
const dbUser = process.env.DB_USER || process.env.MYSQL_USER || process.env.DB_USERNAME || "";
const dbPass = process.env.DB_PASS || process.env.MYSQL_PASSWORD || process.env.DB_PASSWORD || "";
const dbName = process.env.DB_NAME || process.env.MYSQL_DATABASE || process.env.DATABASE || "";
const dbPort = Number(process.env.DB_PORT || process.env.MYSQL_PORT || 3306);

if (!dbUser || !dbName) {
  throw new Error(
    `DB config missing. Check apps/api/.env. Read DB_USER="${dbUser}", DB_NAME="${dbName}"`
  );
}

const pool = mysql.createPool({
  host: dbHost,
  user: dbUser,
  password: dbPass,
  database: dbName,
  port: dbPort,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// log query errors with sql+params (sangat membantu)
const originalQuery = pool.query.bind(pool);
pool.query = async (sql, params) => {
  try {
    return await originalQuery(sql, params);
  } catch (err) {
    console.error("DB QUERY ERROR:");
    console.error("SQL:", sql);
    console.error("PARAMS:", params);
    console.error("MESSAGE:", err?.message);
    throw err;
  }
};

export default pool;