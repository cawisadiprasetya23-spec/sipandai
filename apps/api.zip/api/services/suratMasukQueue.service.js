//D:\surat-menyurat-monorepo\apps\api\services\suratMasukQueue.service.js
import * as repo from "../repositories/suratMasukQueue.repository.js";

const toNull = (v) => {
  if (v === undefined || v === null) return null;
  if (typeof v === "string") {
    const s = v.trim();
    if (s === "" || s === "null" || s === "undefined") return null;
    return s;
  }
  return v;
};
const toIntOrNull = (v) => {
  v = toNull(v);
  if (v === null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};
const isAdminRole = (user) => {
  const role = (user?.role || user?.role_name || "").toLowerCase();
  return ["admin", "superadmin", "kepala_badan", "pimpinan"].includes(role);
};

export async function listQueue(req) {
  const state = toNull(req.query.state) || "not_disposed";
  const allowedStates = ["not_disposed", "in_disposition", "completed"];
  if (!allowedStates.includes(state)) {
    const err = new Error("state tidak valid");
    err.status = 400;
    throw err;
  }

  const unitScope = {
    isAdmin: isAdminRole(req.user),
    unitId: toIntOrNull(req.user?.unit_id),
  };

  return repo.listSuratMasukQueue({
    state,
    search: toNull(req.query.search),
    unitScope,
  });
}