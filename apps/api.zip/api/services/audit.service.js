import pool from "../db.js";

export async function writeAuditLog({
  actor_user_id,
  actor_unit_id,
  action,
  entity_type,
  entity_id,
  message,
  metadata,
  req,
}) {
  const ip =
    req?.headers?.["x-forwarded-for"]?.toString()?.split(",")?.[0]?.trim() ||
    req?.socket?.remoteAddress ||
    null;

  const ua = req?.headers?.["user-agent"] || null;

  await pool.query(
    `
    INSERT INTO audit_logs (
      actor_user_id, actor_unit_id, action, entity_type, entity_id,
      ip, user_agent, message, metadata
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
    [
      actor_user_id ?? null,
      actor_unit_id ?? null,
      action,
      entity_type,
      entity_id ?? null,
      ip,
      ua,
      message ?? null,
      metadata ? JSON.stringify(metadata) : null,
    ]
  );
}