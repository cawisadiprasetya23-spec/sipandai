import * as dispRepo from "../repositories/disposisiMonitoring.repository.js";
import * as tlRepo from "../repositories/disposisiTindakLanjut.repository.js";

const toIntOrNull = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

function isAdminRole(user) {
  const role = (user?.role || user?.role_name || "").toLowerCase();
  return ["admin", "superadmin"].includes(role);
}

export async function uploadLampiran(req, disposisiId, filename) {
  disposisiId = toIntOrNull(disposisiId);
  if (!disposisiId) {
    const err = new Error("disposisiId tidak valid");
    err.status = 400;
    throw err;
  }

  const disposisi = await dispRepo.getDisposisiById(disposisiId);
  if (!disposisi) {
    const err = new Error("Disposisi tidak ditemukan");
    err.status = 404;
    throw err;
  }

  const unitId = toIntOrNull(req.user?.unit_id);
  const admin = isAdminRole(req.user);

  // Model A: hanya unit penerima / admin
  if (!admin) {
    if (!unitId || disposisi.kepada_unit_id !== unitId) {
      const err = new Error("Forbidden: hanya unit penerima yang boleh upload lampiran tindak lanjut");
      err.status = 403;
      throw err;
    }
  }

  const tl = await tlRepo.getByDisposisiId(disposisiId);
  if (!tl) {
    const err = new Error("Isi tindak lanjut terlebih dahulu sebelum upload lampiran");
    err.status = 400;
    throw err;
  }

  await tlRepo.setLampiranByDisposisiId(disposisiId, filename);

  return {
    ok: true,
    disposisi_id: disposisiId,
    lampiran: filename,
    url: `/uploads/tindak-lanjut/${filename}`,
  };
}