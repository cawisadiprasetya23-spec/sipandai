import * as repo from "../repositories/dashboard.repository.js";
import * as auditRepo from "../repositories/auditLogs.repository.js";

const role = (u) => String(u?.role_slug || u?.role || u?.slug || "").toLowerCase();
const toInt = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);

function isAdmin(u) {
  const r = role(u);
  return r === "admin" || r === "superadmin";
}

async function buildSekretariat(req) {
  const unitId = toInt(req.user?.unit_id); // unit sekretariat (wajibnya diisi)
  const userId = toInt(req.user?.id);

  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const tomorrowStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  const weekStart = new Date(todayStart);
  weekStart.setDate(weekStart.getDate() - 7);

  const [today, week, withoutFile, queue] = await Promise.all([
    repo.getSuratMasukCountRange(todayStart, tomorrowStart),
    repo.getSuratMasukCountRange(weekStart, tomorrowStart),
    repo.listSuratMasukWithoutFile(5),
    repo.getQueueCounts(),
  ]);

  const [unitOpenCount, unitLatest, personalOpenCount, personalLatest] = await Promise.all([
    unitId ? repo.getOpenDisposisiCountForUnit(unitId) : Promise.resolve(0),
    unitId ? repo.listLatestDisposisiForUnit(unitId, 5) : Promise.resolve([]),
    userId ? repo.getOpenDisposisiCountForUser(userId) : Promise.resolve(0),
    userId ? repo.listLatestDisposisiForUser(userId, 5) : Promise.resolve([]),
  ]);

  return {
    role: role(req.user),
    unitId,
    widgets: {
      surat_masuk_today: today,
      surat_masuk_week: week,
      without_file_list: withoutFile,

      queue_not_disposed: queue.not_disposed,
      queue_in_disposition: queue.in_disposition,

      disposisi_unit_open: unitOpenCount,
      disposisi_unit_latest: unitLatest,

      disposisi_personal_open: personalOpenCount,
      disposisi_personal_latest: personalLatest,

      quick_actions: [
        { key: "create_surat_masuk", label: "Tambah surat masuk", href: "/surat-masuk/tambah" },
        { key: "upload_lampiran", label: "Upload lampiran", href: "/surat-masuk" },
        { key: "queue_not_disposed", label: "Belum Didisposisi", href: "/dashboard/surat?tab=belum-didisposisi" },
        { key: "sekretariat_queue", label: "Antrian Sekretariat", href: "/dashboard/surat?tab=dalam-disposisi&scope=unit" },
      ],
    },
  };
}

export async function getDashboardSummary(req) {
  const r = role(req.user);

  // Sekretariat: operator & sekretaris share core
  if (r === "operator" || r === "sekretaris") {
    return buildSekretariat(req);
  }

  if (r === "kepala-badan") {
    const [queue, notDisposedLatest, overdueCount, overdueLatest] = await Promise.all([
      repo.getQueueCounts(),
      repo.listNotDisposedLatest(5),
      repo.getOverdueDisposisiCount(),
      repo.listOverdueDisposisiLatest(5),
    ]);

    return {
      role: r,
      widgets: {
        not_disposed_count: queue.not_disposed,
        not_disposed_latest: notDisposedLatest,
        in_disposition_count: queue.in_disposition,
        overdue_count: overdueCount,
        overdue_latest: overdueLatest,
        quick_actions: [
          { key: "go_queue_not_disposed", label: "Buka Belum Didisposisi", href: "/dashboard/surat?tab=belum-didisposisi" },
        ],
      },
    };
  }

  if (r === "kabid") {
    const unitId = toInt(req.user?.unit_id);
    if (!unitId) {
      const err = new Error("User Kabid belum terhubung ke Unit (unit_id kosong).");
      err.status = 400;
      throw err;
    }

    const [openCount, overdueCount, returnedCount, latest] = await Promise.all([
      repo.getOpenDisposisiCountForUnit(unitId),
      repo.getOverdueCountForUnit(unitId),
      repo.getReturnedCountForUnit(unitId),
      repo.listLatestDisposisiForUnit(unitId, 5),
    ]);

    return {
      role: r,
      unitId,
      widgets: {
        open_in_unit: openCount,
        overdue_in_unit: overdueCount,
        returned_need_fix: returnedCount,
        latest_in_unit: latest,
        quick_actions: [
          { key: "go_in_disposition_unit", label: "Dalam Disposisi (Unit Saya)", href: "/dashboard/surat?tab=dalam-disposisi&scope=unit" },
          { key: "go_returned_unit", label: "Returned (Unit Saya)", href: "/dashboard/surat?tab=returned&scope=unit" },
        ],
      },
    };
  }

  if (isAdmin(req.user)) {
    const [queue, overdueCount, auditLatest] = await Promise.all([
      repo.getQueueCounts(),
      repo.getOverdueDisposisiCount(),
      auditRepo.listLatest(10),
    ]);

    return {
      role: r,
      widgets: {
        queue,
        overdue_disposisi: overdueCount,
        audit_latest: auditLatest,
        quick_links: [
          { key: "master_users", label: "Master Users", href: "/master/users" },
          { key: "master_units", label: "Master Units", href: "/master/units" },
          { key: "audit_logs", label: "Audit Logs", href: "/audit-logs" },
        ],
      },
    };
  }

  return { role: r || "unknown", widgets: {} };
}