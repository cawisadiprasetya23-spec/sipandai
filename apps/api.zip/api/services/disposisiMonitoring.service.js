import * as repo from "../repositories/disposisiMonitoring.repository.js";
import * as suratQueueRepo from "../repositories/suratMasukQueue.repository.js";
import * as tlService from "./disposisiTindakLanjut.service.js";

const toNull = (v) => {
  if (v === undefined || v === null) return null;
  if (typeof v === "string") {
    const s = v.trim();
    if (s === "" || s === "null" || s === "undefined") return null;
    return s;
  }
  return v;
};
const toIntOrNull = (v) => {
  v = toNull(v);
  if (v === null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

const isAdminRole = (user) => {
  const role = (user?.role || user?.role_name || "").toLowerCase();
  return ["admin", "superadmin"].includes(role); // ✅ Kepala Badan bukan admin untuk update status (Model A)
};

const allowedStatuses = ["sent", "received", "in_progress", "done", "returned", "cancelled"];

export async function getMonitoringBySurat(req, suratMasukId) {
  suratMasukId = toIntOrNull(suratMasukId);
  if (!suratMasukId) {
    const err = new Error("suratMasukId tidak valid");
    err.status = 400;
    throw err;
  }

  const data = await repo.listDisposisiBySuratId(suratMasukId);

  // RBAC view:
  // - admin: boleh lihat semua
  // - selain admin: hanya boleh lihat jika unit terlibat (dari/kepada)
  const admin = isAdminRole(req.user);
  const unitId = toIntOrNull(req.user?.unit_id);

  if (!admin && unitId) {
    const involved = data.some((d) => d.dari_unit_id === unitId || d.kepada_unit_id === unitId);
    if (!involved) {
      const err = new Error("Forbidden");
      err.status = 403;
      throw err;
    }
  }

  return data;
}

export async function setStatus(req, { id, status, catatan }) {
  id = toIntOrNull(id);
  status = toNull(status);

  if (!id) {
    const err = new Error("ID tidak valid");
    err.status = 400;
    throw err;
  }

  if (!allowedStatuses.includes(status)) {
    const err = new Error("status tidak valid");
    err.status = 400;
    throw err;
  }

  const disposisi = await repo.getDisposisiById(id);
  if (!disposisi) return { notFound: true };

  const admin = isAdminRole(req.user);
  const unitId = toIntOrNull(req.user?.unit_id);

  // ✅ Model A: hanya unit penerima (kepada_unit) atau admin yang boleh update status
  if (!admin) {
    if (!unitId || disposisi.kepada_unit_id !== unitId) {
      const err = new Error("Forbidden: hanya unit penerima yang boleh mengubah status disposisi");
      err.status = 403;
      throw err;
    }
  }

  // returned wajib catatan
  const note = toNull(catatan);
  if (status === "returned" && !note) {
    const err = new Error("Catatan alasan wajib diisi untuk status returned");
    err.status = 400;
    throw err;
  }

  if (status === "done") {
    await tlService.assertCanMarkDone(id);
  }

  const affected = await repo.updateDisposisiStatus({ id, status, catatan: note });
  if (!affected) return { notFound: true };

  // update state surat untuk queue
  await suratQueueRepo.recomputeAndUpdateDisposisiState(disposisi.surat_masuk_id);

  return { ok: true, surat_masuk_id: disposisi.surat_masuk_id };
}