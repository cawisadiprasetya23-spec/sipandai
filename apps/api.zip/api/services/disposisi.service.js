import * as repo from "../repositories/disposisi.repository.js";
import { writeAuditLog } from "./audit.service.js";
import pool from "../db.js";
import * as suratQueueRepo from "../repositories/suratMasukQueue.repository.js";
//import * as suratMasukRepo from "../repositories/surat_masuk.repository.js";

const toNull = (v) => {
  if (v === undefined || v === null) return null;
  if (typeof v === "string") {
    const s = v.trim();
    if (s === "" || s === "null" || s === "undefined") return null;
    return s;
  }
  return v;
};

const toIntOrNull = (v) => {
  v = toNull(v);
  if (v === null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

const isAdminRole = (user) => {
  const role = (user?.role || user?.role_name || "").toLowerCase();
  return ["admin", "superadmin", "kepala_badan", "pimpinan"].includes(role);
};

async function getUserUnitIdFromDb(userId) {
  if (!userId) return null;
  const [rows] = await pool.query(`SELECT unit_id FROM users WHERE id = ? LIMIT 1`, [userId]);
  return rows?.[0]?.unit_id ?? null;
}

// helper: +3 hari default (YYYY-MM-DD)
function plusDaysYmd(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

export async function list(req) {
  const unitId = toIntOrNull(req.user?.unit_id);
  const unitScope = { isAdmin: isAdminRole(req.user), unitId };

  return repo.listDisposisi({
    search: toNull(req.query.search),
    surat_masuk_id: toIntOrNull(req.query.surat_masuk_id),
    unitScope,
  });
}

export async function detail(req, id) {
  const unitId = toIntOrNull(req.user?.unit_id);
  const unitScope = { isAdmin: isAdminRole(req.user), unitId };

  const data = await repo.getDisposisiById(id);
  if (!data) return null;

  // RBAC check untuk detail
  if (!unitScope.isAdmin && unitScope.unitId) {
    const allowed =
      data.dari_unit_id === unitScope.unitId ||
      data.kepada_unit_id === unitScope.unitId ||
      data.unit_tujuan_id === unitScope.unitId; // jika nanti kamu join unit_tujuan_id (opsional)
    if (!allowed) {
      const err = new Error("Forbidden");
      err.status = 403;
      throw err;
    }
  }

  return data;
}

export async function create(req, body) {
  const actor_user_id = toIntOrNull(req.user?.id);
  let actor_unit_id = toIntOrNull(req.user?.unit_id);

  const kepada_unit_id = toIntOrNull(body.kepada_unit_id);

  // ✅ fallback unit_id jika token tidak memuat unit_id
  if (!actor_unit_id && actor_user_id) {
    actor_unit_id = toIntOrNull(await getUserUnitIdFromDb(actor_user_id));
  }

  // ✅ final fallback agar tidak NULL (mencegah error DB)
  // Paling aman: jika masih null, gunakan kepada_unit_id (supaya record tidak gagal)
  if (!actor_unit_id && kepada_unit_id) {
    actor_unit_id = kepada_unit_id;
  }

  const payload = {
    surat_masuk_id: toIntOrNull(body.surat_masuk_id),
    dari_unit_id: actor_unit_id,       // ✅ sekarang tidak null (selama kepada_unit_id ada)
    dari_user_id: actor_user_id,
    kepada_unit_id,
    kepada_user_id: toIntOrNull(body.kepada_user_id),
    instruksi: toNull(body.instruksi),
    catatan: toNull(body.catatan),

    // ✅ due_date optional, tapi kalau kosong set default +3 hari
    due_date: toNull(body.due_date) || plusDaysYmd(3),

    status: toNull(body.status) || "sent",
  };

  if (!payload.surat_masuk_id) {
    const err = new Error("surat_masuk_id wajib");
    err.status = 400;
    throw err;
  }
  if (!payload.kepada_unit_id) {
    const err = new Error("kepada_unit_id wajib");
    err.status = 400;
    throw err;
  }
  if (!payload.dari_unit_id) {
    const err = new Error("dari_unit_id tidak bisa null (cek user.unit_id/token)");
    err.status = 400;
    throw err;
  }

  const id = await repo.createDisposisi(payload);

  // ✅ isi unit tujuan surat masuk jika masih NULL (disposisi pertama / belum ditentukan)
  
  await suratMasukRepo.setUnitTujuanIfNull(payload.surat_masuk_id, payload.kepada_unit_id);
  // ✅ update state surat (kalau kamu pakai fitur queue state)
  try {
    await suratQueueRepo.recomputeAndUpdateDisposisiState(payload.surat_masuk_id);
  } catch (e) {
    console.error("WARN recompute disposisi_state failed:", e);
  }

  await writeAuditLog({
    actor_user_id,
    actor_unit_id: payload.dari_unit_id,
    action: "CREATE",
    entity_type: "disposisi",
    entity_id: id,
    message: "Membuat disposisi",
    metadata: {
      surat_masuk_id: payload.surat_masuk_id,
      dari_unit_id: payload.dari_unit_id,
      kepada_unit_id: payload.kepada_unit_id,
      due_date: payload.due_date,
    },
    req,
  });

  return { id };
}

export async function update(req, id, body) {
  const actor_user_id = toIntOrNull(req.user?.id);
  let actor_unit_id = toIntOrNull(req.user?.unit_id);
  if (!actor_unit_id && actor_user_id) actor_unit_id = toIntOrNull(await getUserUnitIdFromDb(actor_user_id));

  const existing = await repo.getDisposisiById(id);
  if (!existing) return { notFound: true };

  const admin = isAdminRole(req.user);
  const allowed =
    admin ||
    existing.dari_unit_id === actor_unit_id ||
    existing.kepada_unit_id === actor_unit_id;

  if (!allowed) {
    const err = new Error("Forbidden");
    err.status = 403;
    throw err;
  }

  const payload = {
    kepada_unit_id: toIntOrNull(body.kepada_unit_id) ?? existing.kepada_unit_id,
    kepada_user_id: toIntOrNull(body.kepada_user_id),
    instruksi: toNull(body.instruksi),
    catatan: toNull(body.catatan),
    due_date: toNull(body.due_date) || existing.due_date, // tidak diubah kalau kosong
    status: toNull(body.status) || existing.status,
  };

  const affected = await repo.updateDisposisi(id, payload);
  if (!affected) return { notFound: true };

  try {
    await suratQueueRepo.recomputeAndUpdateDisposisiState(existing.surat_masuk_id);
  } catch (e) {
    console.error("WARN recompute disposisi_state failed:", e);
  }

  await writeAuditLog({
    actor_user_id,
    actor_unit_id,
    action: "UPDATE",
    entity_type: "disposisi",
    entity_id: id,
    message: "Mengubah disposisi",
    metadata: { changes: payload },
    req,
  });

  return { ok: true };
}

export async function remove(req, id) {
  const actor_user_id = toIntOrNull(req.user?.id);
  let actor_unit_id = toIntOrNull(req.user?.unit_id);
  if (!actor_unit_id && actor_user_id) actor_unit_id = toIntOrNull(await getUserUnitIdFromDb(actor_user_id));

  const existing = await repo.getDisposisiById(id);
  if (!existing) return { notFound: true };

  const admin = isAdminRole(req.user);
  const allowed = admin || existing.dari_unit_id === actor_unit_id;

  if (!allowed) {
    const err = new Error("Forbidden");
    err.status = 403;
    throw err;
  }

  const affected = await repo.softDeleteDisposisi(id);
  if (!affected) return { notFound: true };

  try {
    await suratQueueRepo.recomputeAndUpdateDisposisiState(existing.surat_masuk_id);
  } catch (e) {
    console.error("WARN recompute disposisi_state failed:", e);
  }

  await writeAuditLog({
    actor_user_id,
    actor_unit_id,
    action: "DELETE",
    entity_type: "disposisi",
    entity_id: id,
    message: "Menghapus disposisi (soft delete)",
    req,
  });

  return { ok: true };
}