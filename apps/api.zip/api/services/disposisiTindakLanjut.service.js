import * as tlRepo from "../repositories/disposisiTindakLanjut.repository.js";
import * as dispRepo from "../repositories/disposisiMonitoring.repository.js"; // reuse getDisposisiById
import * as suratQueueRepo from "../repositories/suratMasukQueue.repository.js";

const toNull = (v) => {
  if (v === undefined || v === null) return null;
  if (typeof v === "string") {
    const s = v.trim();
    if (!s || s === "null" || s === "undefined") return null;
    return s;
  }
  return v;
};
const toIntOrNull = (v) => {
  v = toNull(v);
  if (v === null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

function requireDateYmd(v, fieldName) {
  const s = toNull(v);
  if (!s) {
    const err = new Error(`${fieldName} wajib diisi (YYYY-MM-DD)`);
    err.status = 400;
    throw err;
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) {
    const err = new Error(`${fieldName} format harus YYYY-MM-DD`);
    err.status = 400;
    throw err;
  }
  return s;
}

export async function get(req, disposisiId) {
  disposisiId = toIntOrNull(disposisiId);
  if (!disposisiId) {
    const err = new Error("disposisiId tidak valid");
    err.status = 400;
    throw err;
  }

  const disposisi = await dispRepo.getDisposisiById(disposisiId);
  if (!disposisi) return { notFound: true };

  // RBAC: admin boleh, unit terlibat boleh lihat
  const unitId = toIntOrNull(req.user?.unit_id);
  const role = String(req.user?.role || req.user?.role_name || "").toLowerCase();
  const isAdmin = ["admin", "superadmin"].includes(role);

  if (!isAdmin && unitId) {
    const involved = disposisi.dari_unit_id === unitId || disposisi.kepada_unit_id === unitId;
    if (!involved) {
      const err = new Error("Forbidden");
      err.status = 403;
      throw err;
    }
  }

  const tl = await tlRepo.getByDisposisiId(disposisiId);
  return { disposisi, tindak_lanjut: tl };
}

export async function upsert(req, disposisiId, body) {
  disposisiId = toIntOrNull(disposisiId);
  if (!disposisiId) {
    const err = new Error("disposisiId tidak valid");
    err.status = 400;
    throw err;
  }

  const disposisi = await dispRepo.getDisposisiById(disposisiId);
  if (!disposisi) return { notFound: true };

  const unitId = toIntOrNull(req.user?.unit_id);
  const userId = toIntOrNull(req.user?.id);

  // ✅ Model A: hanya unit penerima (kepada_unit) yang boleh mengisi tindak lanjut.
  // admin boleh override.
  const role = String(req.user?.role || req.user?.role_name || "").toLowerCase();
  const isAdmin = ["admin", "superadmin"].includes(role);
  if (!isAdmin) {
    if (!unitId || disposisi.kepada_unit_id !== unitId) {
      const err = new Error("Forbidden: hanya unit penerima disposisi yang boleh mengisi tindak lanjut");
      err.status = 403;
      throw err;
    }
  }

  const uraian = toNull(body?.uraian);
  if (!uraian) {
    const err = new Error("uraian wajib diisi");
    err.status = 400;
    throw err;
  }

  const tanggal_selesai = requireDateYmd(body?.tanggal_selesai, "tanggal_selesai");
  const hasil = toNull(body?.hasil);
  const lampiran = toNull(body?.lampiran); // ini string nama file jika upload terpisah

  const existing = await tlRepo.getByDisposisiId(disposisiId);

  if (!existing) {
    const id = await tlRepo.create({
      disposisi_id: disposisiId,
      uraian,
      hasil,
      tanggal_selesai,
      lampiran,
      dibuat_oleh_user_id: userId,
      dibuat_oleh_unit_id: unitId,
    });
    return { created: true, id };
  }

  await tlRepo.updateByDisposisiId(disposisiId, { uraian, hasil, tanggal_selesai, lampiran });
  return { updated: true };
}

export async function remove(req, disposisiId) {
  disposisiId = toIntOrNull(disposisiId);
  if (!disposisiId) {
    const err = new Error("disposisiId tidak valid");
    err.status = 400;
    throw err;
  }

  const disposisi = await dispRepo.getDisposisiById(disposisiId);
  if (!disposisi) return { notFound: true };

  const unitId = toIntOrNull(req.user?.unit_id);
  const role = String(req.user?.role || req.user?.role_name || "").toLowerCase();
  const isAdmin = ["admin", "superadmin"].includes(role);

  if (!isAdmin) {
    if (!unitId || disposisi.kepada_unit_id !== unitId) {
      const err = new Error("Forbidden");
      err.status = 403;
      throw err;
    }
  }

  const affected = await tlRepo.softDeleteByDisposisiId(disposisiId);
  return { ok: affected > 0 };
}

/**
 * Hook untuk memastikan "done" hanya jika tindak lanjut sudah ada.
 * Dipanggil dari disposisiMonitoring.service.js sebelum update status ke done.
 */
export async function assertCanMarkDone(disposisiId) {
  const tl = await tlRepo.getByDisposisiId(disposisiId);
  if (!tl) {
    const err = new Error("Tidak bisa set status done: tindak lanjut belum diisi");
    err.status = 400;
    throw err;
  }
  return true;
}

/**
 * Setelah status berubah, update state surat.
 */
export async function afterStatusChange(suratMasukId) {
  await suratQueueRepo.recomputeAndUpdateDisposisiState(suratMasukId);
}