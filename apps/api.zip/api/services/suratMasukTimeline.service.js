//D:\surat-menyurat-monorepo\apps\api\services\suratMasukTimeline.service.js
import * as repo from "../repositories/suratMasukTimeline.repository.js";

const toIntOrNull = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

function isAdminRole(user) {
  const role = (user?.role || user?.role_name || "").toLowerCase();
  return ["admin", "superadmin", "kepala_badan", "pimpinan"].includes(role);
}

export async function getTimeline(req, suratMasukId) {
  suratMasukId = toIntOrNull(suratMasukId);
  if (!suratMasukId) {
    const err = new Error("suratMasukId tidak valid");
    err.status = 400;
    throw err;
  }

  const surat = await repo.getSuratMasukBasic(suratMasukId);
  if (!surat) return { notFound: true };

  // RBAC view:
  // admin/pimpinan lihat semua, selain itu batasi unit tujuan & keterlibatan disposisi
  const admin = isAdminRole(req.user);
  const unitId = toIntOrNull(req.user?.unit_id);

  const disposisiRows = await repo.listDisposisiWithTL(suratMasukId);

  if (!admin && unitId) {
    const involved =
      surat.unit_tujuan_id === unitId ||
      disposisiRows.some((d) => d.dari_unit_id === unitId || d.kepada_unit_id === unitId);

    if (!involved) {
      const err = new Error("Forbidden");
      err.status = 403;
      throw err;
    }
  }

  // Build timeline events
  const events = [];

  // Surat masuk dibuat (registrasi)
  events.push({
    time: surat.created_at || surat.tanggal_terima,
    type: "surat_created",
    title: "Surat masuk diregistrasi",
    detail: `${surat.nomor_surat || "-"} • ${surat.asal_surat || "-"} • ${surat.perihal || "-"}`,
    ref: { surat_masuk_id: surat.id },
  });

  // Lampiran surat utama jika ada
  if (surat.file_surat) {
    events.push({
      time: surat.created_at || surat.tanggal_terima,
      type: "surat_file",
      title: "Lampiran surat utama tersedia",
      detail: surat.file_surat,
      ref: { surat_masuk_id: surat.id, filename: surat.file_surat },
    });
  }

  // Disposisi & tindak lanjut
  for (const row of disposisiRows) {
    events.push({
      time: row.disposisi_created_at,
      type: "disposisi_created",
      title: `Disposisi dibuat → ${row.kepada_unit_name || row.kepada_unit_id || "-"}`,
      detail: row.instruksi || "-",
      ref: { disposisi_id: row.disposisi_id },
    });

    // Status terakhir (snapshot)
    events.push({
      time: row.disposisi_updated_at || row.disposisi_created_at,
      type: "disposisi_status",
      title: `Status disposisi: ${row.status || "sent"}`,
      detail: row.catatan || "",
      ref: { disposisi_id: row.disposisi_id },
    });

    if (row.tindak_lanjut_id) {
      events.push({
        time: row.tl_created_at,
        type: "tindak_lanjut_created",
        title: "Tindak lanjut diisi",
        detail: row.tl_uraian || "-",
        ref: { disposisi_id: row.disposisi_id, tindak_lanjut_id: row.tindak_lanjut_id },
      });

      if (row.tl_lampiran) {
        events.push({
          time: row.tl_updated_at || row.tl_created_at,
          type: "tindak_lanjut_file",
          title: "Lampiran tindak lanjut diupload",
          detail: row.tl_lampiran,
          ref: { disposisi_id: row.disposisi_id, filename: row.tl_lampiran },
        });
      }
    }
  }

  // Optional audit logs (kalau ada)
  const audit = await repo.listAuditLogsByEntity(suratMasukId);
  for (const a of audit) {
    events.push({
      time: a.created_at,
      type: "audit",
      title: a.action || "Audit Log",
      detail: a.description || "",
      ref: { audit_log_id: a.id },
      actor: {
        name: a.actor_name || "",
        unit: a.actor_unit_name || "",
      },
    });
  }

  // sort by time ascending
  events.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());

  return { surat, events };
}